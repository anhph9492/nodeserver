TOKEN=$(curl -u release.tvsw:Flfflwm1212?? "localhost:4000/api/auth/genAccessToken?type=once&userid=taehun.nam" | jq -r .token)
echo created token : $TOKEN
curl -w " - status code: %{http_code}" -H "Authorization: Bearer $TOKEN" localhost:4000/api/auth/check

