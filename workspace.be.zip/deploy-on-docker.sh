PROJECT_NAME="platz.be"

docker login -u $1 -p $2 docker-registry.lge.com/project/platz
docker pull docker-registry.lge.com/project/platz/${PROJECT_NAME}:latest
docker run -d -p 4001:4001 --name ${PROJECT_NAME} docker-registry.lge.com/project/platz/${PROJECT_NAME}:latest
