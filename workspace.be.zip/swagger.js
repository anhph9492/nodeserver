import swaggerAutogen from 'swagger-autogen';

const doc={
    info:{
        title:'workspace-backend API',
        description :'backend API'
    },
    host: 'workspace.hedej.lge.com',
    schemes:["https"]

};

const outputFile= './swagger-output.json';
const routes =[
    './src/api/api/database/index.js',
    './src/api/api/publish/index.js',
    './src/api/api/dns/index.js',
    './src/api/api/project/index.js',
    './src/api/api/template/index.js',
    './src/api/api/setting/index.js',
    './src/api/api/iam/index.js'
];

swaggerAutogen()(outputFile, routes, doc);