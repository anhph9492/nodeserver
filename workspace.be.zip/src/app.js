import cors from '@koa/cors';
import Koa from 'koa';

import amp from 'app-module-path';
import bodyParser from 'koa-bodyparser';
import logger from 'koa-logger';
import serve from 'koa-static';
import path from 'path';
// import proxy from 'koa-proxies';
import { Issuer } from 'openid-client';
import { jwtMiddleware, jwtSocketMiddleware } from './lib/token.js';

import api from './api/index.js';

import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { podProxy } from './lib/podProxy.js';
import platzwsHandler from './websockets/platz.js';

const __dirname = fileURLToPath(new URL('.', import.meta.url));
const directory = path.resolve(__dirname, './static');
amp.addPath(`${__dirname}`);
dotenv.config();

const issuer = await Issuer.discover(process.env.OIDC_ISSUER);
console.log('Discovered issuer', issuer.issuer);
global.userinfo_endpoint = issuer.userinfo_endpoint;

//prepare to OIDC Authorization Code flow
global.oidcClient = new issuer.Client({
	client_id: process.env.OIDC_CLIENT_ID,
	client_secret: process.env.OIDC_CLIENT_SECRET,
	redirect_uris: [process.env.OIDC_CALLBACK_URI],
	response_types: ['code'],
});

function createApp({ isProduction, io }) {
	const app = new Koa();
	app.proxy = true;
	console.log("oidc Client? >>>>> ",global.oidcClient)
	app.use(
		logger({
			transporter: (str, args) => {
				console.log(`${new Date()}:${str}`);
			},
		}),
	);

	app.use(cors({ origin: ctx => ctx.headers.origin, credentials: true }));
	app.use(jwtMiddleware);


	app.use(async (ctx, next) => {
		ctx.io = io;
		await next();
	});

	
	let wss;
	[wss] = platzwsHandler(io)
	wss.use(jwtSocketMiddleware);

	app.use(podProxy);
	app.use(bodyParser({ formLimit: '16MB', jsonLimit: '16MB', textLimit: '16MB' }));
	app.use(async (ctx, next) => {
		ctx.io = global.io;
		await next();
	});

	app.use(serve(directory));
	app.use(api.routes()).use(api.allowedMethods());

	return app;
}

export default createApp;
