// import User from '../models/user.js';
// import Docs from '../models/hedej/docs.js';
// import Pages from '../models/hedej/pages.js';

function platzwsHandler(io) {
	console.log('[Listen] platz websocket listen');

	let rooms = {};

	const joinRoom = (room, id) => {
		// if (!room.startsWith('workspace/')) {
		// 	return;
		// }

		// console.log(room, id)
		if (rooms[room] === undefined) {
			rooms[room] = new Set();
		}
		rooms[room].add(id);
		// console.log(rooms)
	};

	const leaveRoom = (room, id) => {
		if (room === '*') {
			Object.keys(rooms).forEach(roomId => {
				rooms[roomId].delete(id);

				if (rooms[roomId].size === 0) {
					delete rooms[roomId];
				}
			});
		} else {
			if (rooms[room] === undefined) {
				rooms[room] = new Set();
			}

			if (rooms[room].has(id)) {
				rooms[room].delete(id);
			}

			if (rooms[room].size === 0) {
				delete rooms[room];
			}
		}

		// console.log(rooms)
	};

	//나에게 연결 된 소켓이 Room에 들어 갈 경우
	io.of('/hedej').adapter.on('leave-room', (room, id) => {
		console.log(`[this]socket ${id} has leaved room ${room}`);
		leaveRoom(room, id);
	});

	io.of('/hedej').adapter.on('join-room', (room, id) => {
		console.log(`[this]socket ${id} has joined room ${room}`);
		joinRoom(room, id);
	});

	//남에게 연결 된 소켓이 Room에 들어 갈 경우
	const leaveHandler = data => {
			// console.log(`[other]socket ${data.id} has leaved room ${data.room}`);
			leaveRoom(data.room, data.id);
		},
		joinHandler = data => {
			// console.log(`[other]socket ${data.id} has joined room ${data.room}`);
			joinRoom(data.room, data.id);
		};

	io.of('/hedej').on('connection', async socket => {
		const user = socket.user || {};
		console.log(`${new Date()}: ${user.sub}[${socket.id} <${socket.request.connection.remoteAddress}>] was established`);

		if (user.sub !== undefined) {
			io.of('/hedej')
				.in(socket.id)
				.socketsJoin('user/' + user.sub);
		}

		socket.on('error', error => {
			console.err(`${new Date()}: ${user.sub}[${socket.id} <${socket.request.connection.remoteAddress}>] error : ${error}`);
		});

		socket.on('close', () => {
			console.log(`${new Date()}: ${user.sub}[${socket.id} <${socket.request.connection.remoteAddress}>] closed`);
		});
		socket.on('disconnect', async () => {
			io.of('/hedej').in(socket.id).socketsLeave('*');
			console.log(`${new Date()}: ${user.sub}[${socket.id} <${socket.request.connection.remoteAddress}>] disconnected`);
		});

		// socket.on('user', async () => {
		// 	socket.emit('user', { user: await getUserNewMap() });
		// });

		socket.on('listen', async msg => {
			console.log(`${new Date()}: ${user.sub}[${socket.id} <${socket.request.connection.remoteAddress}>] listen : ${msg.to}`);
			// socket?.join("doc/"+msg.doc_id)

			if (!(msg.to instanceof Array)) {
				msg.to = [msg.to];
			}

			msg.to.forEach(target => {
				io.of('/hedej').in(socket.id).socketsJoin(target);
			});

			// if (msg?.doc_id !== undefined && msg?.doc_id !== '') {
			// 	io.of('/hedej')
			// 		.in(socket.id)
			// 		.socketsJoin('doc/' + msg.doc_id);
			// }
			// if (msg?.page_id !== undefined && msg?.doc_id !== '') {
			// 	io.of('/hedej')
			// 		.in(socket.id)
			// 		.socketsJoin('page/' + msg.page_id);
			// }
		});

		socket.on('disregard', async msg => {
			console.log(`${new Date()}: ${user.sub}[${socket.id} <${socket.request.connection.remoteAddress}>] disregard : ${msg.to}`);

			if (!(msg.to instanceof Array)) {
				msg.to = [msg.to];
			}

			msg.to.forEach(target => {
				socket?.leave(target);
			});

			io.of('/hedej')
				.in(socket.id)
				.socketsLeave('doc/' + msg.to);
		});
	});

	return [io.of('/hedej'), joinHandler, leaveHandler];
}

export default platzwsHandler;
