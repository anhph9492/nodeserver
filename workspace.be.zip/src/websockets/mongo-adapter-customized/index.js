"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
export const MongoAdapter = export const createAdapter = void 0;
import socket_io_adapter_1  from "socket.io-adapter";
import crypto_1  from "crypto";
const randomId = () => crypto_1.randomBytes(8).toString("hex");
import debug  from "debug")("socket.io-mongo-adapter";

/**
 * Event types, for messages between nodes
 */
var EventType;
(function (EventType) {
    EventType[EventType["INITIAL_HEARTBEAT"] = 1] = "INITIAL_HEARTBEAT";
    EventType[EventType["HEARTBEAT"] = 2] = "HEARTBEAT";
    EventType[EventType["BROADCAST"] = 3] = "BROADCAST";
    EventType[EventType["SOCKETS_JOIN"] = 4] = "SOCKETS_JOIN";
    EventType[EventType["SOCKETS_LEAVE"] = 5] = "SOCKETS_LEAVE";
    EventType[EventType["DISCONNECT_SOCKETS"] = 6] = "DISCONNECT_SOCKETS";
    EventType[EventType["FETCH_SOCKETS"] = 7] = "FETCH_SOCKETS";
    EventType[EventType["FETCH_SOCKETS_RESPONSE"] = 8] = "FETCH_SOCKETS_RESPONSE";
    EventType[EventType["SERVER_SIDE_EMIT"] = 9] = "SERVER_SIDE_EMIT";
    EventType[EventType["SERVER_SIDE_EMIT_RESPONSE"] = 10] = "SERVER_SIDE_EMIT_RESPONSE";
    EventType[EventType["BROADCAST_CLIENT_COUNT"] = 11] = "BROADCAST_CLIENT_COUNT";
    EventType[EventType["BROADCAST_ACK"] = 12] = "BROADCAST_ACK";
})(EventType || (EventType = {}));
/**
 * UID of an emitter using the `@socket.io/mongo-emitter` package
 */
const EMITTER_UID = "emitter";
let joinHandler, leaveHandler;

/**
 * It seems the `promoteBuffers` option is not always honored, so we manually replace Binary objects by the underlying
 * Buffer objects.
 *
 * Reference:
 * - http://mongodb.github.io/node-mongodb-native/3.6/api/Binary.html
 * - https://jira.mongodb.org/browse/NODE-1421
 */
const replaceBinaryObjectsByBuffers = (obj) => {
    if (!obj || typeof obj !== "object") {
        return obj;
    }
    if (obj._bsontype === "Binary" && Buffer.isBuffer(obj.buffer)) {
        return obj.buffer;
    }
    if (Array.isArray(obj)) {
        for (let i = 0; i < obj.length; i++) {
            obj[i] = replaceBinaryObjectsByBuffers(obj[i]);
        }
    }
    else {
        for (const key in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, key)) {
                obj[key] = replaceBinaryObjectsByBuffers(obj[key]);
            }
        }
    }
    return obj;
};
/**
 * Returns a function that will create a MongoAdapter instance.
 *
 * @param mongoCollection - a MongoDB collection instance
 * @param opts - additional options
 *
 * @public
 */
function createAdapter(mongoCollection, opts = {}, _joinHandler, _leaveHandler) {
    joinHandler = _joinHandler
    leaveHandler = _leaveHandler
    opts.uid = opts.uid || randomId();
    let isClosed = false;
    let adapters = new Map();
    let changeStream;
    const initChangeStream = () => {
        if (isClosed) {
            return;
        }
        if (changeStream) {
            changeStream.removeAllListeners("change");
            changeStream.removeAllListeners("close");
        }
        changeStream = mongoCollection.watch([
            {
                $match: {
                    "fullDocument.uid": {
                        $ne: opts.uid,
                    },
                },
            },
        ]);
        changeStream.on("change", (event) => {
            var _a, _b;
            (_b = adapters.get((_a = event.fullDocument) === null || _a === void 0 ? void 0 : _a.nsp)) === null || _b === void 0 ? void 0 : _b.onEvent(event);
        });
        changeStream.on("error", (err) => {
            debug("change stream encountered an error: %s", err.message);
        });
        changeStream.on("close", () => {
            debug("change stream was closed, scheduling reconnection...");
            setTimeout(() => {
                initChangeStream();
            }, 1000);
        });
    };
    return function (nsp) {
        if (!changeStream) {
            isClosed = false;
            initChangeStream();
        }
        let adapter = new MongoAdapter(nsp, mongoCollection, opts);
        adapters.set(nsp.name, adapter);
        const defaultClose = adapter.close;
        adapter.close = () => {
            adapters.delete(nsp.name);
            if (adapters.size === 0) {
                changeStream.removeAllListeners("close");
                changeStream.close();
                changeStream = null;
                isClosed = true;
            }
            defaultClose.call(adapter);
        };
        return adapter;
    };
}
export const createAdapter = createAdapter;
class MongoAdapter extends socket_io_adapter_1.Adapter {
    /**
     * Adapter constructor.
     *
     * @param nsp - the namespace
     * @param mongoCollection - a MongoDB collection instance
     * @param opts - additional options
     *
     * @public
     */
    constructor(nsp, mongoCollection, opts = {}) {
        super(nsp);
        this.nodesMap = new Map(); // uid => timestamp of last message
        this.requests = new Map();
        this.ackRequests = new Map();
        this.mongoCollection = mongoCollection;
        this.uid = opts.uid;
        this.requestsTimeout = opts.requestsTimeout || 5000;
        this.heartbeatInterval = opts.heartbeatInterval || 5000;
        this.heartbeatTimeout = opts.heartbeatTimeout || 10000;
        this.addCreatedAtField = !!opts.addCreatedAtField;
        this.publish({
            type: EventType.INITIAL_HEARTBEAT,
        });
    }
    close() {
        if (this.heartbeatTimer) {
            clearTimeout(this.heartbeatTimer);
        }
        return;
    }
    async onEvent(event) {
        const document = event.fullDocument;
        debug("new event of type %d for %s from %s", document.type, document.nsp, document.uid);
        if (document.uid && document.uid !== EMITTER_UID) {
            this.nodesMap.set(document.uid, Date.now());
        }
        switch (document.type) {
            case EventType.INITIAL_HEARTBEAT: {
                this.publish({
                    type: EventType.HEARTBEAT,
                });
                break;
            }
            case EventType.BROADCAST: {
                debug("broadcast with opts %j", document.data.opts);
                const withAck = document.data.requestId !== undefined;
                if (withAck) {
                    super.broadcastWithAck(replaceBinaryObjectsByBuffers(document.data.packet), MongoAdapter.deserializeOptions(document.data.opts), (clientCount) => {
                        debug("waiting for %d client acknowledgements", clientCount);
                        this.publish({
                            type: EventType.BROADCAST_CLIENT_COUNT,
                            data: {
                                requestId: document.data.requestId,
                                clientCount,
                            },
                        });
                    }, (arg) => {
                        debug("received acknowledgement with value %j", arg);
                        this.publish({
                            type: EventType.BROADCAST_ACK,
                            data: {
                                requestId: document.data.requestId,
                                packet: arg,
                            },
                        });
                    });
                }
                else {
                    super.broadcast(replaceBinaryObjectsByBuffers(document.data.packet), MongoAdapter.deserializeOptions(document.data.opts));
                }
                break;
            }
            case EventType.BROADCAST_CLIENT_COUNT: {
                const request = this.ackRequests.get(document.data.requestId);
                request === null || request === void 0 ? void 0 : request.clientCountCallback(document.data.clientCount);
                break;
            }
            case EventType.BROADCAST_ACK: {
                const request = this.ackRequests.get(document.data.requestId);
                const clientResponse = replaceBinaryObjectsByBuffers(document.data.packet);
                request === null || request === void 0 ? void 0 : request.ack(clientResponse);
                break;
            }
            case EventType.SOCKETS_JOIN: {
                debug("calling addSockets with opts %j", document.data.opts);
                console.log("join id", document.data.opts?.rooms,"=> room" ,document.data.rooms);
                
                document.data.opts?.rooms.forEach((id) => {
                    document.data.rooms.forEach((room) => {
                        joinHandler({id, room})
                        
                    })
                })
                
                super.addSockets(MongoAdapter.deserializeOptions(document.data.opts), document.data.rooms);
                break;
            }
            case EventType.SOCKETS_LEAVE: {
                debug("calling delSockets with opts %j", document.data.opts);
                console.log("leave", document.data.opts.rooms,"<=" ,document.data.rooms);
                
                document.data.opts?.rooms.forEach((id) => {
                    document.data.rooms.forEach((room) => {
                        leaveHandler({id, room});
                    })
                })
                super.delSockets(MongoAdapter.deserializeOptions(document.data.opts), document.data.rooms);
                break;
            }
            case EventType.DISCONNECT_SOCKETS: {
                console.log("calling disconnectSockets with opts %j", document.data.opts);
                super.disconnectSockets(MongoAdapter.deserializeOptions(document.data.opts), document.data.close);
                break;
            }
            case EventType.FETCH_SOCKETS: {
                console.log("calling fetchSockets with opts %j", document.data.opts);
                const localSockets = await super.fetchSockets(MongoAdapter.deserializeOptions(document.data.opts));
                this.publish({
                    type: EventType.FETCH_SOCKETS_RESPONSE,
                    data: {
                        requestId: document.data.requestId,
                        sockets: localSockets.map((socket) => ({
                            id: socket.id,
                            handshake: socket.handshake,
                            rooms: [...socket.rooms],
                            data: socket.data,
                        })),
                    },
                });
                break;
            }
            case EventType.FETCH_SOCKETS_RESPONSE: {
                const request = this.requests.get(document.data.requestId);
                if (!request) {
                    return;
                }
                request.current++;
                document.data.sockets.forEach((socket) => request.responses.push(socket));
                if (request.current === request.expected) {
                    clearTimeout(request.timeout);
                    request.resolve(request.responses);
                    this.requests.delete(document.data.requestId);
                }
                break;
            }
            case EventType.SERVER_SIDE_EMIT: {
                const packet = document.data.packet;
                const withAck = document.data.requestId !== undefined;
                if (!withAck) {
                    this.nsp._onServerSideEmit(packet);
                    return;
                }
                let called = false;
                const callback = (arg) => {
                    // only one argument is expected
                    if (called) {
                        return;
                    }
                    called = true;
                    debug("calling acknowledgement with %j", arg);
                    this.publish({
                        type: EventType.SERVER_SIDE_EMIT_RESPONSE,
                        data: {
                            requestId: document.data.requestId,
                            packet: arg,
                        },
                    });
                };
                packet.push(callback);
                this.nsp._onServerSideEmit(packet);
                break;
            }
            case EventType.SERVER_SIDE_EMIT_RESPONSE: {
                const request = this.requests.get(document.data.requestId);
                if (!request) {
                    return;
                }
                request.current++;
                request.responses.push(document.data.packet);
                if (request.current === request.expected) {
                    clearTimeout(request.timeout);
                    request.resolve(null, request.responses);
                    this.requests.delete(document.data.requestId);
                }
            }
        }
    }
    scheduleHeartbeat() {
        if (this.heartbeatTimer) {
            clearTimeout(this.heartbeatTimer);
        }
        this.heartbeatTimer = setTimeout(() => {
            this.publish({
                type: EventType.HEARTBEAT,
            });
            this.scheduleHeartbeat();
        }, this.heartbeatInterval);
    }
    publish(document) {
        document.uid = this.uid;
        document.nsp = this.nsp.name;
        if (this.addCreatedAtField) {
            document.createdAt = new Date();
        }
        this.mongoCollection.insertOne(document);
        this.scheduleHeartbeat();
    }
    /**
     * Transform ES6 Set into plain arrays
     */
    static serializeOptions(opts) {
        return {
            rooms: [...opts.rooms],
            except: opts.except ? [...opts.except] : [],
            flags: opts.flags,
        };
    }
    static deserializeOptions(opts) {
        return {
            rooms: new Set(opts.rooms),
            except: new Set(opts.except),
            flags: opts.flags,
        };
    }
    broadcast(packet, opts) {
        var _a;
        const onlyLocal = (_a = opts === null || opts === void 0 ? void 0 : opts.flags) === null || _a === void 0 ? void 0 : _a.local;
        if (!onlyLocal) {
            this.publish({
                type: EventType.BROADCAST,
                data: {
                    packet,
                    opts: MongoAdapter.serializeOptions(opts),
                },
            });
        }
        // packets with binary contents are modified by the broadcast method, hence the nextTick()
        process.nextTick(() => {
            super.broadcast(packet, opts);
        });
    }
    broadcastWithAck(packet, opts, clientCountCallback, ack) {
        var _a;
        const onlyLocal = (_a = opts === null || opts === void 0 ? void 0 : opts.flags) === null || _a === void 0 ? void 0 : _a.local;
        if (!onlyLocal) {
            const requestId = randomId();
            this.publish({
                type: EventType.BROADCAST,
                data: {
                    packet,
                    requestId,
                    opts: MongoAdapter.serializeOptions(opts),
                },
            });
            this.ackRequests.set(requestId, {
                type: EventType.BROADCAST,
                clientCountCallback,
                ack,
            });
            // we have no way to know at this level whether the server has received an acknowledgement from each client, so we
            // will simply clean up the ackRequests map after the given delay
            setTimeout(() => {
                this.ackRequests.delete(requestId);
            }, opts.flags.timeout);
        }
        // packets with binary contents are modified by the broadcast method, hence the nextTick()
        process.nextTick(() => {
            super.broadcastWithAck(packet, opts, clientCountCallback, ack);
        });
    }
    serverCount() {
        return Promise.resolve(1 + this.nodesMap.size);
    }
    addSockets(opts, rooms) {
        var _a;
        super.addSockets(opts, rooms);
        const onlyLocal = (_a = opts.flags) === null || _a === void 0 ? void 0 : _a.local;
        if (onlyLocal) {
            return;
        }
        this.publish({
            type: EventType.SOCKETS_JOIN,
            data: {
                opts: MongoAdapter.serializeOptions(opts),
                rooms,
            },
        });
    }
    delSockets(opts, rooms) {
        var _a;
        super.delSockets(opts, rooms);
        const onlyLocal = (_a = opts.flags) === null || _a === void 0 ? void 0 : _a.local;
        if (onlyLocal) {
            return;
        }
        this.publish({
            type: EventType.SOCKETS_LEAVE,
            data: {
                opts: MongoAdapter.serializeOptions(opts),
                rooms,
            },
        });
    }
    disconnectSockets(opts, close) {
        var _a;
        super.disconnectSockets(opts, close);
        const onlyLocal = (_a = opts.flags) === null || _a === void 0 ? void 0 : _a.local;
        if (onlyLocal) {
            return;
        }
        this.publish({
            type: EventType.DISCONNECT_SOCKETS,
            data: {
                opts: MongoAdapter.serializeOptions(opts),
                close,
            },
        });
    }
    getExpectedResponseCount() {
        this.nodesMap.forEach((lastSeen, uid) => {
            const nodeSeemsDown = Date.now() - lastSeen > this.heartbeatTimeout;
            if (nodeSeemsDown) {
                debug("node %s seems down", uid);
                this.nodesMap.delete(uid);
            }
        });
        return this.nodesMap.size;
    }
    async fetchSockets(opts) {
        var _a;
        const localSockets = await super.fetchSockets(opts);
        const expectedResponseCount = this.getExpectedResponseCount();
        if (((_a = opts.flags) === null || _a === void 0 ? void 0 : _a.local) || expectedResponseCount === 0) {
            return localSockets;
        }
        const requestId = randomId();
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                const storedRequest = this.requests.get(requestId);
                if (storedRequest) {
                    reject(new Error(`timeout reached: only ${storedRequest.current} responses received out of ${storedRequest.expected}`));
                    this.requests.delete(requestId);
                }
            }, this.requestsTimeout);
            const storedRequest = {
                type: EventType.FETCH_SOCKETS,
                resolve,
                timeout,
                current: 0,
                expected: expectedResponseCount,
                responses: localSockets,
            };
            this.requests.set(requestId, storedRequest);
            this.publish({
                type: EventType.FETCH_SOCKETS,
                data: {
                    opts: MongoAdapter.serializeOptions(opts),
                    requestId,
                },
            });
        });
    }
    serverSideEmit(packet) {
        const withAck = typeof packet[packet.length - 1] === "function";
        if (withAck) {
            this.serverSideEmitWithAck(packet).catch(() => {
                // ignore errors
            });
            return;
        }
        this.publish({
            type: EventType.SERVER_SIDE_EMIT,
            data: {
                packet,
            },
        });
    }
    async serverSideEmitWithAck(packet) {
        const ack = packet.pop();
        const expectedResponseCount = this.getExpectedResponseCount();
        debug('waiting for %d responses to "serverSideEmit" request', expectedResponseCount);
        if (expectedResponseCount <= 0) {
            return ack(null, []);
        }
        const requestId = randomId();
        const timeout = setTimeout(() => {
            const storedRequest = this.requests.get(requestId);
            if (storedRequest) {
                ack(new Error(`timeout reached: only ${storedRequest.current} responses received out of ${storedRequest.expected}`), storedRequest.responses);
                this.requests.delete(requestId);
            }
        }, this.requestsTimeout);
        const storedRequest = {
            type: EventType.FETCH_SOCKETS,
            resolve: ack,
            timeout,
            current: 0,
            expected: expectedResponseCount,
            responses: [],
        };
        this.requests.set(requestId, storedRequest);
        this.publish({
            type: EventType.SERVER_SIDE_EMIT,
            data: {
                requestId,
                packet,
            },
        });
    }
}
export const MongoAdapter = MongoAdapter;
