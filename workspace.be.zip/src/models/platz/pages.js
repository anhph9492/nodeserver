import Rows  from "../../models/platz/rows.js";
import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

var viewerScheme = new Schema({ 
    name: String, 
    type: String, 
    property : Schema.Types.Mixed
  });
  
const pagesSchema = new Schema({
    commentlist : [mongoose.Schema.Types.ObjectId],
    graphlist : [mongoose.Schema.Types.ObjectId],
    blocklist : [mongoose.Schema.Types.ObjectId],
    layout:mongoose.Schema.Types.Mixed,
    viewers:[viewerScheme],
    ref : {type: Schema.Types.ObjectId},
    type : {type : String, default:"pages"},
    pid : String,
    viewers:[viewerScheme],
    lastModified : {type: Date, default: Date.now},
    created : {type: Date, default: Date.now},
    by: {type: Schema.Types.ObjectId, ref: 'User'},
    name : String,
    desc : String,
    permissions_reader : [{type: Schema.Types.ObjectId, ref: 'User'}],
    permissions_writer : [{type: Schema.Types.ObjectId, ref: 'User'}],
    icon : String,
});

export default mongoose.model('pages', pagesSchema);