import User  from "../user.js";
import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const notification = new Schema({
  name : String,
  content : Schema.Types.Mixed,
  lastModified : {type: Date, default: Date.now},
  to: {type: Schema.Types.ObjectId, ref: 'User'},
  by: {type: Schema.Types.ObjectId, ref: 'User'},
});

export default mongoose.model('notification', notification);