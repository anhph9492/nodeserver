import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const rowsSchema = new Schema({
    lastModified : {type: Date, default: Date.now},
    created : {type: Date, default:Date.now},
    parentId: {type: Schema.Types.ObjectId, ref: 'Docs'},
    by: {type: Schema.Types.ObjectId, ref: 'User'}
}, { strict: false });

export default mongoose.model('rows', rowsSchema);