import User  from "../user.js";
import Docs  from "./docs.js";
import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const messageSchema = new Schema({
  ref:mongoose.Schema.Types.ObjectId,
  doc:{type: Schema.Types.ObjectId, ref:'docs'},
  type:String,
  body : mongoose.Schema.Types.Mixed,
  isRead : {type : Boolean, default:false},
  created : {type: Date, default: Date.now},
  by: {type: Schema.Types.ObjectId, ref: 'User'},
  to: {type: Schema.Types.ObjectId, ref: 'User'},
});

export default mongoose.model('message', messageSchema);