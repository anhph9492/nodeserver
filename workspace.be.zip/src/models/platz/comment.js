import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const commentSchema = new Schema({
    lastModified : {type: Date, default: Date.now},
    ref: {type: Schema.Types.ObjectId, ref: 'docs'},
    refType:String,
    by: {type: Schema.Types.ObjectId, ref: 'User'},
    value:String,
});

export default mongoose.model('comment', commentSchema);