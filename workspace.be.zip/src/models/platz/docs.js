import User  from "../user.js";
import config from "./config.js"
import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

var fieldAttrScheme = new Schema({ 
  name: String, 
  type: String, 
  tag: [String], 
  multiple: Boolean, 
  options : Schema.Types.Mixed,
  width : Number,
});

var viewerScheme = new Schema({ 
  name: String, 
  type: String, 
  property : Schema.Types.Mixed
});

var sheetScheme = new Schema({
  fields : [fieldAttrScheme], 
  index : [mongoose.Schema.Types.ObjectId],
  name : String
})

const docsSchema = new Schema({
  fields:[fieldAttrScheme],
  viewers:[viewerScheme],
  index:[mongoose.Schema.Types.ObjectId],
  name : String,
  type : {type : String, default:"doc"},
  pid : String,
  desc : String,
  lastModified : {type: Date, default: Date.now},
  created : {type: Date, default: Date.now},
  by: {type: Schema.Types.ObjectId, ref: 'User'},
  fixedCols : [Number],
  permissions_reader : [{type: Schema.Types.ObjectId, ref: 'User'}],
  permissions_writer : [{type: Schema.Types.ObjectId, ref: 'User'}],
  sheets : [sheetScheme],
  icon : String,
  format : String,
});

export default mongoose.model('docs', docsSchema);