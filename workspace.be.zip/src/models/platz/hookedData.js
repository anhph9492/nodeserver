import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const hookedDataSchema = new Schema({
  platz_native_created : {type: Date, default: Date.now},
  platz_native_updated : {type: Date, default: Date.now},
  platz_native_hook : Schema.Types.Mixed,
  platz_native_key : String,
  
  platz_native_credential : {type: Schema.Types.ObjectId, ref: 'Config'}
}, { strict: false, autoIndexId: false,  _id : false});

hookedDataSchema.index({platz_native_key:1}, {unique:true, dropDups:true})

export default mongoose.model('HookedData', hookedDataSchema);