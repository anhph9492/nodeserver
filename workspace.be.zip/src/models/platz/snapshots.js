import User  from "../user.js";
import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

var fieldAttrScheme = new Schema({ 
  name: String, 
  type: String, 
  options : Schema.Types.Mixed
});

var chartScheme = new Schema({ 
  name: String, 
  type: String, 
  property : Schema.Types.Mixed
});

const snapshotsSchema = new Schema({
  fields:[fieldAttrScheme],
  charts:[chartScheme],
  index:[mongoose.Schema.Types.ObjectId],
  name : String,
  desc : String,
  ref : mongoose.Schema.Types.ObjectId,
  lastModified : {type: Date, default: Date.now},
  by: {type: Schema.Types.ObjectId, ref: 'User'},
  fixedCols : [Number],
  rows : {type : Schema.Types.Mixed},
  versions : String
});

export default mongoose.model('snapshots', snapshotsSchema);