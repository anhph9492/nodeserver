import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const configSchema = new Schema({
  attributeName : {type : String, unique : false},
  value : Schema.Types.Mixed,
  lastModified : {type: Date, default: Date.now},
  doc : {type: Schema.Types.ObjectId, ref: 'docs'},
  for : {type: Schema.Types.ObjectId, ref: 'User'},
  by: {type: Schema.Types.ObjectId, ref: 'User'}
});

export default mongoose.model('config', configSchema);