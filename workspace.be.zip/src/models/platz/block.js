import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const blockSchema = new Schema({
    lastModified : {type: Date, default: Date.now},
    parentId: {type: Schema.Types.ObjectId, ref: 'Docs'},
    by: {type: Schema.Types.ObjectId, ref: 'User'},
    graphlist : [{type:Schema.Types.ObjectId, ref:"elasticChart"}],
    commentlist:[{type:Schema.Types.ObjectId, ref:"Comment"}],
    html:{type:String, default:""}
});

export default mongoose.model('block', blockSchema);