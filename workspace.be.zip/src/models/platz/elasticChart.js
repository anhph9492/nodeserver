import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const elasticChartSchema = new Schema({
    graphData : Schema.Types.Mixed,
    refFieldName : String,
    refDocName : String ,
    name: String,
    by: {type: Schema.Types.ObjectId, ref: 'User'},
    created : {type: Date, default: Date.now},
});

export default mongoose.model('elasticChart', elasticChartSchema);