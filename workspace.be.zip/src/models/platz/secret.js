import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const secretSchema = new Schema({
  attributeName : {type : String, unique : false},
  value : Schema.Types.Mixed,
  lastModified : {type: Date, default: Date.now},
  by: {type: Schema.Types.ObjectId, ref: 'User'}
});

export default mongoose.model('secret', secretSchema);