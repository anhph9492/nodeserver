import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const platzHistorySchema = new Schema({
	table: String,
	before: Schema.Types.Mixed,
	after: Schema.Types.Mixed,
	diff: Schema.Types.Mixed,
	comment: String,
	ref: { type: Schema.Types.ObjectId },
	by: { type: Schema.Types.ObjectId, ref: 'User' },
	date: { type: Date, default: Date.now, index: true },
	undo: Boolean, //history 객체에 저장 할 내용
	undoFor: { type: Schema.Types.ObjectId }, //undo 객체에 저장 할 내용
});

export default mongoose.model('platzhistories', platzHistorySchema);
