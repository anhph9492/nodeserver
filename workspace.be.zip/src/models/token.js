import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const tokenSchema = new Schema({
  token:{type:String, index:true},
  type: String,
  until: Date,
  created: {type: Date, default: Date.now},
  for : {type: Schema.Types.ObjectId, ref: 'User'},
  by : {type: Schema.Types.ObjectId, ref: 'User'},
});

const Token = mongoose.model('Token', tokenSchema);
export default Token