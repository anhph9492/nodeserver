import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const attachmentSchema = new Schema({}, { strict: false });

const Attachment = mongoose.model('Attachment', attachmentSchema, 'attachment.files');
export default Attachment