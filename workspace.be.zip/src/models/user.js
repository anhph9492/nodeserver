import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const userSchema = new Schema({
    userid: String,
  name: String,
  mail : String,
  group : String,
  permission: Schema.Types.Mixed,
  config : Schema.Types.Mixed,
  groupid: String,
  members : [{type: Schema.Types.ObjectId, ref: 'User'}],
  empno : String,
  encodedPw : String,
  profilePhoto : {type:Schema.Types.ObjectId, ref: 'Attachment'}
});

const User = mongoose.model('User', userSchema);
export default User;