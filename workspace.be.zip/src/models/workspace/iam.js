import mongoose from 'mongoose';
const Schema= mongoose.Schema;

const iamSchema = new Schema({
    iamName:{type:String, unique:true},
    creator:Schema.Types.Mixed,
    created:{type: Date, default: Date.now},
    lastModified:{type: Date, default: Date.now},
});

export default mongoose.model('iam',iamSchema);