import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const settingSchema = new Schema({
    gitAuthorName:{type:String},
    gitAuthorEmail:{type:String},
    timezone:{type:String, default: "Asia/Seoul"},
    language:{type:String, default:"ko_KR.utf8"},
    gitlabToken:{type:String},
    theme:{type:String, default:"light"},
    created:{type:Date, default:Date.now},
    lastModified:{type:Date, default:Date.now} 
});

export default mongoose.model('setting',settingSchema);