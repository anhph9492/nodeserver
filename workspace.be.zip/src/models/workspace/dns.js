import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const dnsSchema = new Schema({
    url:{type:String},
    ip:{type:String},
    cert:{type:String},
    key:{type:String},
    created:{type: Date, default: Date.now},
    firedDate:{type:Date},
    connectedPublish:{type:Schema.Types.ObjectId, ref:'publish'},
    lastModified:{type: Date, default: Date.now},
    by:{type:Schema.Types.ObjectId, ref:'User'} // by도 User로 찾는건지?
});

export default mongoose.model('dns',dnsSchema)