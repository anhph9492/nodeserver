import mongoose from 'mongoose';
const Schema= mongoose.Schema;

const userSchema=new Schema({
    sub:{type:String},
    name:{type:String},
    family_name:{type:String},
    given_name:{type:String},
    email:{type:String},
    email_verified:Boolean,
    preferred_username:{type:String},
    idToken:{type:String},
    admin:{type:Boolean, default:false}
});

export default mongoose.model('user', userSchema);