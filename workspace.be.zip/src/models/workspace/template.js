import mongoose from 'mongoose';
const Schema= mongoose.Schema;

const templateSchema= new Schema({
    name:String,
    type:Schema.Types.Mixed,
    version:String,
    created:{type: Date, default: Date.now},
});

export default mongoose.model('template', templateSchema);