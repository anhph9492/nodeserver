import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const projectSchema = new Schema({
    name:{type:String, unique:true},
    description:{type:String},
    iamName:{type:String, ref:'iam'},
    storage:{type:String, default:"10Gi"},
    templateRef:{type:Schema.Types.ObjectId, ref:'template'},
    cejCategory:{type:Schema.Types.Mixed, default:[]},
    dejCategory:{type:Schema.Types.Mixed, default:[]},
    databaseId:{type:Schema.Types.ObjectId, ref:'database'},
    created:{type: Date, default: Date.now},
    lastModified:{type: Date, default: Date.now},
    status:{type:String}

});

export default mongoose.model('project',projectSchema)