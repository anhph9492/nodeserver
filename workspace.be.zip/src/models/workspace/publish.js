import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const publishSchema = new Schema({
    projectId:{type:Schema.Types.ObjectId, ref:'project'},
    date:{type:Date, default:Date.now},
    version:{type:String},
    containerName:{type:String},
    containerVersion:{type:String, default:"0.0.1"}, // 그냥 version과 containerVersion의 차이? 
    dnsId:{type:Schema.Types.ObjectId, ref:"dns"},
    iamName:{type:String, ref:'iam'},
    rating:{type:Number},
    category:Schema.Types.Mixed,
});

export default mongoose.model('publish',publishSchema)