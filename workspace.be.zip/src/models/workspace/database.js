import mongoose from 'mongoose';
const Schema= mongoose.Schema;

const databaseSchema=new Schema({
    databaseType:{type:String},
    name:{type:String},
    storage:{type:String},
    cpu:{type:String},
    memory:{type:String},
    iamName:{type:String, ref:'iam'},
    databaseId:{type:String},
    databasePwd:{type:String},
    podName:Schema.Types.Mixed,
    created:{type: Date, default: Date.now},
    lastModified:{type: Date, default: Date.now},
});

export default mongoose.model('database',databaseSchema);