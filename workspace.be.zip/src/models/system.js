import mongoose  from 'mongoose';
const Schema = mongoose.Schema;

const systemSchema = new Schema({
  name: String,
  fullname: String,
});

const System = mongoose.model('System', systemSchema);
export default System;