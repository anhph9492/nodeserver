// const hmr = require('node-hmr');
// import hmr from 'node-hmr';
import App from './app.js';
import http from 'http';
import { Server as SocketIoServer } from 'socket.io';

import { MongoClient } from 'mongodb';
import mongoose from 'mongoose';
let callback;

const socketio_collection = 'ws';
const isProduction = process.env.NODE_ENV === 'production';
const port = process.env.PORT || 4000;

let mongoUrl;
const mongoOptions = {
	maxPoolSize: 10,
	useNewUrlParser: true,
	useUnifiedTopology: true,
};

mongoUrl = `mongodb://${process.env.MONGO_USER}:${process.env.MONGO_PASS}@${process.env.MONGO_HOST}/${process.env.MONGO_COLLECTION}?directConnection=true`;
// mongodb://workspace_admin:workspace_admin@10.159.48.238:27017/workspace

// if (isProduction) {
// 	mongoUrl = `mongodb://${process.env.MONGO_USER}:${process.env.MONGO_PASS}@${process.env.MONGO_HOST}/${process.env.MONGO_COLLECTION}?replicaSet=rs0`;
// } else {
// 	mongoUrl = 'mongodb://platz:platz@10.159.48.242:27017/workspace?authMechanism=DEFAULT';
// }

console.log('[state] mongodb url', mongoUrl);

const mongoClient = new MongoClient(mongoUrl, { useUnifiedTopology: true });
await mongoClient.connect();

try {
	await mongoClient.db(process.env.MONGO_COLLECTION).createCollection(socketio_collection, {
		capped: true,
		size: 1e6,
	});
} catch (e) {
	console.log('[Warning] already exist ' + socketio_collection, e.message);
}

console.log('[Connected] Mongodb for socket.io');

mongoose.Promise = global.Promise;
await mongoose.connect(mongoUrl, mongoOptions).catch(err => {
	console.error(err);
});

console.log('[Connected] Mongoose');

const socketioOptions = {
	cors: (res, next) => {
		next(null, { origin: res.headers.origin, credentials: true });
	},
};

const io = new SocketIoServer(socketioOptions);
global.io = io;

const app = App({ isProduction, io });
callback = app.callback();
const httpServer = http.createServer(callback);

io.attach(httpServer);

httpServer.listen(port, () => {
	console.log(`[Listen] http port ${port}`);
});
