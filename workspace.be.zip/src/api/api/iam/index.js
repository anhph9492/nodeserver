import Router from 'koa-router';

const iam = new Router();

iam.put('/', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.description='create new iam'
    #swagger.path ='/api/iam'
    #swagger.parameters['body']={
        in:'body',
        schema:{
            iamName:''
        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'',
            creator:'',
            created:'2023-10-23T04:08:48.312+00:00',
            lastModified:'2023-10-23T04:08:48.312+00:00'
        }
    }
    */


});

iam.put('/role',async ctx =>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam/role'
    #swagger.description='create new role in specific iam'
    #swagger.parameters['body']={
        in:'body',
        schema:{
            iamName:'',
            newRole:''
        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'',
            creator:'',
            created:'2023-10-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */

});

iam.post('/', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam'
    #swagger.description='update existed iam'
    #swagger.parameters['body']={
        in:'body',
        schema:{
            orig_iamName:'',
            update_iamName:''
        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'',
            creator:'',
            created:'2023-10-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */

});

iam.post('/role', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam/role'
    #swagger.description='update existed role'
    #swagger.parameters['body']={
        in:'body',
        schema:{
            iamName:'',
            orig_role:'',
            update_role:''

        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'',
            creator:'',
            created:'2023-10-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */

});

iam.delete('/', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam'
    #swagger.description='delete existed iam'
    #swagger.parameters['body']={
        in:'body',
        schema:{
            iamName:''

        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
        }
    }
    */

});

iam.delete('/role', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam/role'
    #swagger.description='delete existed role'
   #swagger.parameters['body']={
        in:'body',
        schema:{
            iamName:'xxx',
            role:'test'

        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'xxx',
            roles:["default","admin"],
            creator:'',
            created:'2023-10-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */

});
iam.get('/', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam'
    #swagger.description='list detail of iam'
    #swagger.parameters['iamName']= { in:'query', description :'name of iam that user want to retrieve detail"}
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'',
            roles:["default","admin"],
            creator:'',
            created:'2023-10-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */

});

iam.get('/role', async ctx=>{
    /*
    #swagger.tags=['iam']
    #swagger.path ='/api/iam/role'
    #swagger.description='list detail of existed role'
    #swagger.parameters['iamName']= { in:'query', description :'name of iam that user want to retrieve detail"}
    #swagger.parameters['role']= { in:'query', description :'name of role that user want to retrieve detail"}
    #swagger.responses[200]={
        description:'',
        schema:{
            iamName:'',
            role:'',
            attributes:[]
        }
    }
    */

});
export default iam;