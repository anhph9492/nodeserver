export const getSecret = props =>{
  const {secretName, databaseType}=props
    return {
        apiVersion: "v1",
        kind: "Secret",
        metadata: {
            name: secretName,
            namespace: 'workspace'
        },
        data: {
            random: "QmQ0M3lwTGlzZ2JIamlCWW9abS8rU0tYWkxScUxFOG5wZEdocjVqWlBPbkVGSUQ4cmJVblRzVHVnY29STzRmdQpyVGd4V3FrY2RBZnQ2QjdkVEtiM1VYTWdOemkyeVdYU1NUNlplSy80Q0ZDWGpXZ1c5VVZLWlptMmNteHZLR2lqCm11RGlqd1NuUTNHQWFjNFR3WEF6V0pHcmw4aVZ5d09ZMkloK0QyTzMvc0RkRC9VL3JGbUN3YW5tRDFtQkNneVEKWTFqY0R4V1NCMjBFakxnMmV0UUZRM2lIWTREdFJ6VkIyVGVBL1Z3VnZuMzdFcmxPa0JaeE4wM1VpZU4rRUsyegpPYnpRN2J3WVFHUHA4bVlCM09VbkdXVTA5cDRGQjhoNDM4cE5Qb0xwbUtmdGJabUtJT3N1eDJPQTMxdEppUk5aCllsS1laemUwdkVrREpPcm1ORmNMQzV2YXlHWjJZamxmbktEYXJkVkNtUE9rd0Q1ZnU5cXp5REZxcTI1dThNT3gKNldlTUh0SCtiRE5UZkIrN1VTSGZoMWJHRjlpdW15TDVhZjY2MEdvMjRpUVg3VWVwTWVlamhrSDMrWDV4Ly93NApJaGR6S1pYTkN3Z2tpRk9aa3RMWUVMdFppejZZdjM3TUUvSmxubGtPVzZ4Q0NrUU9aNXI1SWRwVmtqeE5mV1NhCk5sSGg0Z1NMS1RjcXdGb2dBMGRHemFPRzcyVnNVcnpKZy81M3RxLzdMYm8xQ2JQNWRXV2J2SHpWMmp6NkoxZFEKNWN3YW81dHpoMjBWb3cwSklCaVY1UytCS3Vzem5ycXdJL3Y3MjJ5MmtnNDlYYzVrSFhpVEUrM0V6SWVNUVhrcApEWjNWY0oxN1NVZjFrSzJ2QUlmdEczYUgzR1V4M0I5NG5MbWpwSWg2YlBDVjNBL2djOUNmV21HYXhZMG42UjZkCnMyVThOSUxJbDQzMDV2MXhLb1ZMSnd1L3NhVCszVUNmbXVVd0xaaXFTajYyZW01bFV5ZXhaZzZHRXpTZERxODAKZDhKNVpGTW9JVFR0V3JxN3JuMHhnV2FHV2xqNDA0Z2ZsVFptTUxzTHl4N2Z2S1Z3WndqMjRyRUxGeGZTSnhvMQo3ZFJqN2tFVWM3cWFPekVnMitSeXR1aFB3ckpPL3dqL0V1MW9XZlRjMXJqZno4elE0a3BZSHI3Z0ZSaldsUGMrCnAyZXI4b1g3RXVISUdjUHByekNldW9aUERRUmJwT0ZleUlJY3h3NDVXRXlFNmFITmZPbE0wQi9kd3BjRHFVa1kKRllNOHBHM2pEWFdmZkhVNGllc2RiVEJCZ1ppaFdLdkZ3VTZEUUxZdWFMMHlqcXBxCg=="
        }
    }
};
export const getService = props =>{
  const {name, databaseType}=props
    return {
        apiVersion: "v1",
        kind: "Service",
        metadata: {
            name: name,
            namespace: "workspace",
            labels: {
                name: "mongo"
            }
        },
        spec: {
            selector: {
                role: "mongo",
                "statefulset.kubernetes.io/pod-name": `${name}-${databaseType.toLowerCase()}-stf`
            },
            ports: [
                {
                    protocol: "TCP",
                    port: 27017,
                    targetPort: 27017
                }
            ],
            type: "ClusterIP"
        }
    }
};
export const getStatefulSet = props =>{
  const {name, databaseType, storage}=props
    return{
        apiVersion: "apps/v1",
        kind: "StatefulSet",
        metadata: {
          name: `${name}-${databaseType.toLowerCase()}-stf`,
          namespace: "workspace"
        },
        spec: {
          selector: {
            matchLabels: {
              app: "mongo"
            }
          },
          serviceName: `${name}`,
          replicas: 1,
          volumeClaimTemplates: [
            {
              metadata: {
                name: "dbhome",
                annotations: {
                  "nfs.io/storage-path": "hedej-db"
                }
              },
              spec: {
                storageClassName: "nfs-client",
                accessModes: [
                  "ReadWriteOnce"
                ],
                resources: {
                  requests: {
                    storage: storage,
                  }
                }
              }
            }
          ],
          template: {
            metadata: {
              labels: {
                app: "mongo",
                role: "mongo",
                environment: "hedej"
              }
            },
            spec: {
              terminationGracePeriodSeconds: 10,
              containers: [
                {
                  name: `${name}-${databaseType.toLowerCase()}-stf`,
                  image: "mongo:6.0",
                  command: [
                    "mongod",
                    "--replSet",
                    "rs0",
                    "--bind_ip_all",
                    "--auth",
                    "--keyFile",
                    "/var/auth/random"
                  ],
                  ports: [
                    {
                      containerPort: 27017
                    }
                  ],
                  volumeMounts: [
                    {
                      name: "dbhome",
                      mountPath: "/data/db"
                    },
                    {
                      name: `secret-${name}`,
                      mountPath: "/var/auth",
                      readOnly: true
                    }
                  ]
                },
                {
                  name: "mongo-sidecar",
                  image: "cvallance/mongo-k8s-sidecar:latest",
                  env: [
                    {
                      "name": "MONGO_SIDECAR_POD_LABELS",
                      "value": "role=mongo,environment=hedej"
                    }
                  ]
                }
              ],
              volumes: [
                {
                  name: `secret-${name}`,
                  secret: {
                    secretName: `secret-${name}`,
                    defaultMode: 256
                  }
                }
              ]
            }
          }
        }
      }
}
export default {getSecret,getService, getStatefulSet };