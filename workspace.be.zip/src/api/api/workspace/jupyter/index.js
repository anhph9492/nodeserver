export const getPvc = props => {
	const { user, workspace, spec } = props || {};
	const { name, namespace, version } = workspace || { name: 'test', namespace: 'workspace', version: 'latest' };
	const { userid, email } = user || { userid: 'taehun.nam' };
	const { size, cpu, memory } = spec || { size: '20Gi', cpu: '1', memory: '2Gi' };

	// (user = 'taehun.nam', name = 'test', namespace = 'ws-test', size = '20Gi') => {
	const newUser = userid.replace('.', '');

	return {
		apiVersion: 'v1',
		kind: 'PersistentVolumeClaim',
		metadata: {
			name: `jupyter-${newUser}-${name}`,
			namespace,
			annotations: {
				'nfs.io/storage-path': 'devenv',
			},
			labels: {
				ide: 'jupyter',
				creator: 'userid',
				name,
			},
		},
		spec: {
			storageClassName: 'nfs-client',
			accessModes: ['ReadWriteMany'],
			resources: {
				requests: {
					storage: size,
				},
			},
		},
	};
};

export const getDeployment = props => {
	const { user, workspace, spec } = props || {};
	const { name, namespace, version } = workspace || { name: 'test', namespace: 'workspace', version: 'latest' };
	const { userid, email } = user || { userid: 'taehun.nam' };
	const { size, cpu, memory } = spec || { size: '20Gi', cpu: '1', memory: '2Gi' };

	const newUser = userid.replace('.', '');

	return {
		apiVersion: 'apps/v1',
		kind: 'Deployment',
		metadata: {
			name: `jupyter-${newUser}-${name}`,
			namespace,
			labels: {
				ide: 'jupyter',
				creator: userid,
				name,
			},
		},
		spec: {
			selector: {
				matchLabels: {
					app: `jupyter-${newUser}-${name}`,
				},
			},
			replicas: 1,
			template: {
				metadata: {
					labels: {
						app: `jupyter-${newUser}-${name}`,
					},
				},
				spec: {
					containers: [
						{
							name: 'jupyter',
							image: `jupyter/pyspark-notebook:${version}`,
							imagePullPolicy: 'Always',
							ports: [
								{
									containerPort: 8888,
								},
							],
							command: ['start-notebook.sh'],
							args: [`--ServerApp.base_url=/workspace/jupyter/${name}/`, `--NotebookApp.token=''`, `--NotebookApp.password=''`],
							volumeMounts: [
								{
									name: 'config',
									mountPath: '/home/jovyan',
								},
							],
							// livenessProbe: {
							// 	httpGet: {
							// 		path: '/healthz',
							// 		port: 8888,
							// 		scheme: 'HTTP',
							// 	},
							// 	initialDelaySeconds: 40,
							// },
							resources: {
								limits: {
									memory,
									cpu,
								},
								requests: {
									memory: '256Mi',
									cpu: '0.2',
								},
							},
						},
					],
					imagePullSecrets: [
						{
							name: 'registry-key',
						},
					],
					volumes: [
						{
							name: 'config',
							persistentVolumeClaim: {
								claimName: `jupyter-${newUser}-${name}`,
							},
						},
					],
				},
			},
		},
	};
};

export const getService = props => {
	const { user, workspace, spec } = props || {};
	const { name, namespace, version } = workspace || { name: 'test', namespace: 'workspace', version: 'latest' };
	const { userid, email } = user || { userid: 'taehun.nam' };
	const { size, cpu, memory } = spec || { size: '20Gi', cpu: '1', memory: '2Gi' };
	const newUser = userid.replace('.', '');

	return {
		apiVersion: 'v1',
		kind: 'Service',
		metadata: {
			name: `jupyter-${newUser}-${name}`,
			namespace,
		},
		labels: {
			ide: 'jupyter',
			creator: 'userid',
			name,
		},
		spec: {
			selector: {
				app: `jupyter-${newUser}-${name}`,
			},
			ports: [
				{
					protocol: 'TCP',
					port: 8888,
					targetPort: 8888,
				},
			],
			type: 'ClusterIP',
		},
	};
};
export default { getDeployment, getPvc, getService };
