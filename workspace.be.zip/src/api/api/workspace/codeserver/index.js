export const getPvc = props => {
	const { user, workspace, spec } = props || {};
	const { name, namespace, version } = workspace || { name: 'test', namespace: 'workspace', version: 'latest' };
	const { userid, email } = user || { userid: 'taehun.nam' };
	const { size, cpu, memory } = spec || { size: '20Gi', cpu: '1', memory: '2Gi' };

	// (user = 'taehun.nam', name = 'test', namespace = 'ws-test', size = '20Gi') => {
	const newUser = userid.replace('.', '');

	return {
		apiVersion: 'v1',
		kind: 'PersistentVolumeClaim',
		metadata: {
			name: `codeserver-${newUser}-${name}`,
			namespace,
			annotations: {
				'nfs.io/storage-path': 'devenv',
			},
			labels: {
				ide: 'codeserver',
				creator: 'userid',
				name,
			},
		},
		spec: {
			storageClassName: 'nfs-client',
			accessModes: ['ReadWriteMany'],
			resources: {
				requests: {
					storage: size,
				},
			},
		},
	};
};

export const getDeployment = props => {
	const { user, workspace, spec } = props || {};
	const { name, namespace, version } = workspace || { name: 'test', namespace: 'workspace', version: 'latest' };
	const { userid, email } = user || { userid: 'taehun.nam' };
	const { size, cpu, memory } = spec || { size: '20Gi', cpu: '1', memory: '2Gi' };

	const newUser = userid.replace('.', '');

	return {
		apiVersion: 'apps/v1',
		kind: 'Deployment',
		metadata: {
			name: `codeserver-${newUser}-${name}`,
			namespace,
			labels: {
				ide: 'codeserver',
				creator: userid,
				name,
			},
		},
		spec: {
			selector: {
				matchLabels: {
					app: `codeserver-${newUser}-${name}`,
				},
			},
			replicas: 1,
			template: {
				metadata: {
					labels: {
						app: `codeserver-${newUser}-${name}`,
					},
				},
				spec: {
					containers: [
						{
							name: 'codeserver',
							image: `docker-registry.lge.com/project/platz/ide:${version}`,
							imagePullPolicy: 'Always',
							ports: [
								{
									name: 'code-serv',
									containerPort: 8443,
								},
							],
							env: [
								{
									name: 'SUDO_PASSWORD',
									value: 'root',
								},
								{
									name: 'DEFAULT_WORKSPACE',
									value: '/config/workspace',
								},
								{
									name: 'PUID',
									value: '0',
								},
								{
									name: 'PGID',
									value: '0',
								},
								// {
								// 	name: 'PROXY_DOMAIN',
								// 	value: 'hedej.lge.com/workspace/wstest',
								// },
							],
							volumeMounts: [
								{
									name: 'config',
									mountPath: '/config',
								},
							],
							livenessProbe: {
								httpGet: {
									path: '/healthz',
									port: 8443,
									scheme: 'HTTP',
								},
								initialDelaySeconds: 40,
							},
							resources: {
								limits: {
									memory,
									cpu,
								},
								requests: {
									memory: '256Mi',
									cpu: '0.2',
								},
							},
						},
					],
					imagePullSecrets: [
						{
							name: 'registry-key',
						},
					],
					volumes: [
						{
							name: 'config',
							persistentVolumeClaim: {
								claimName: `codeserver-${newUser}-${name}`,
							},
						},
					],
				},
			},
		},
	};
};

export const getService = props => {
	const { user, workspace, spec } = props || {};
	const { name, namespace, version } = workspace || { name: 'test', namespace: 'workspace', version: 'latest' };
	const { userid, email } = user || { userid: 'taehun.nam' };
	const { size, cpu, memory } = spec || { size: '20Gi', cpu: '1', memory: '2Gi' };
	const newUser = userid.replace('.', '');

	return {
		apiVersion: 'v1',
		kind: 'Service',
		metadata: {
			name: `codeserver-${newUser}-${name}`,
			namespace,
		},
		labels: {
			ide: 'codeserver',
			creator: 'userid',
			name,
		},
		spec: {
			selector: {
				app: `codeserver-${newUser}-${name}`,
			},
			ports: [
				{
					protocol: 'TCP',
					port: 8443,
					targetPort: 8443,
				},
			],
			type: 'ClusterIP',
		},
	};
};
export default { getDeployment, getPvc, getService };
