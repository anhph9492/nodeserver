import Router from 'koa-router';
import codeserver from './codeserver/index.js';
import jupyter from './jupyter/index.js';
import { injectUserToKC, k8sApi, k8sAppApi, kc, updateServices } from '../../../lib/kubeConfig.js';
import k8s, { Watch } from '@kubernetes/client-node';

import stream from 'stream';

const log = new k8s.Log(kc);

const workspace = new Router();
const streams = {};
const NAMESPACE = 'workspace';

const list = async ctx => {
	if (ctx.request.user === undefined || !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}
	try {
		const podsRes = await k8sApi.listNamespacedPod(NAMESPACE);
		const deploymentsRes = await k8sAppApi.listNamespacedDeployment(NAMESPACE);
		const serviceRes = await k8sApi.listNamespacedService(NAMESPACE);

		updateServices(serviceRes);
		// console.log(global.services);
		ctx.body = {
			services: serviceRes.response.body.items.map(v => ({ name: v.metadata.name, clusterIP: v.spec.clusterIP })),
			pods: podsRes.body.items.map(v => ({ name: v.metadata.name, status: v.status.phase })),
			deployments: deploymentsRes.body.items.map(v => ({
				name: v.metadata.name,
				labels: v.metadata.labels,
				status: { readyReplicas: v.status.readyReplicas || 0, replicas: v.status.replicas, unavailableReplicas: v.status.unavailableReplicas },
			})),
		};

		// updateServices();
		// console.log(deploymentsRes.body);
	} catch (err) {
		ctx.status = 400;
		ctx.body = err;
		console.error(err);
	}
};

workspace.get('/create', async ctx => {
	// #swagger.tags=[NAMESPACE]
	const { user } = ctx.request;
	console.log("ctx.request? ", ctx.request)
	console.log("user? ",user)

	if (ctx.request.user === undefined || !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}

	const { name, ide } = ctx.query;
	let selectedIde;
	if (ide === undefined || ide === 'codeserver') {
		ide === 'codeserver';
		selectedIde = codeserver;
	} else if (ide === 'jupyter') {
		selectedIde = jupyter;
	}

	const deployment = selectedIde.getDeployment({ workspace: { name, version: 'latest', namespace: NAMESPACE } });
	const pvc = selectedIde.getPvc({ workspace: { name } });
	const svc = selectedIde.getService({ workspace: { name } });
	let createdDeployment, createdPvc, createdSvc;
	try {
		// getService

		createdDeployment = await k8sAppApi.createNamespacedDeployment(NAMESPACE, deployment).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		createdPvc = await k8sApi.createNamespacedPersistentVolumeClaim(NAMESPACE, pvc).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		createdSvc = await k8sApi.createNamespacedService(NAMESPACE, svc).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});

		// console.log('Created deployment: ', createdDeployment.body);
		ctx.body = { createdDeployment: createdDeployment.body, createdPvc: createdPvc.body, createdService: createdSvc.body };
		// console.log('created', createdDeployment.body.metadata.name);
		watchPod(createdDeployment.body.metadata.name, ctx.io);
		await list(ctx);
	} catch (err) {
		console.error('error', err);
		ctx.body = err.message;
		ctx.status = 400;
	}
});

workspace.delete('/', async ctx => {
	// #swagger.tags=[NAMESPACE]
	if (ctx.request.user === undefined || !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}

	const { name, ide } = ctx.query;
	const { user } = ctx.request;

	let selectedIde;
	if (ide === undefined || ide === 'codeserver') {
		ide === 'codeserver';
		selectedIde = codeserver;
	} else if (ide === 'jupyter') {
		selectedIde = jupyter;
	}

	const deployment = selectedIde.getDeployment({ workspace: { name, version: 'latest', namespace: NAMESPACE } });
	const pvc = selectedIde.getPvc({ workspace: { name, version: 'latest', namespace: NAMESPACE } });
	const svc = selectedIde.getService({ workspace: { name, version: 'latest', namespace: NAMESPACE } });
	// console.log(deployment, pvc, svc);
	let createdDeployment, createdPvc, createdSvc;
	try {
		// getService
		watchPod(deployment.metadata.name, ctx.io);

		createdDeployment = await k8sAppApi.deleteNamespacedDeployment(deployment.metadata.name, deployment.metadata.namespace).catch(e => {
			console.error(e);
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		createdPvc = await k8sApi.deleteNamespacedPersistentVolumeClaim(pvc.metadata.name, pvc.metadata.namespace).catch(e => {
			console.error(e);
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		// console.log(svc.metadata.name, svc.metadata.namespace);

		createdSvc = await k8sApi.deleteNamespacedService(svc.metadata.name, svc.metadata.namespace).catch(e => {
			console.error(e);
			const err = new Error();
			err.message = e.body;
			throw err;
		});

		// console.log('Created deployment: ', createdDeployment.body, createdPvc, createdSvc);
		// ctx.body = { createdDeployment: createdDeployment.body, createdPvc: createdPvc.body, createdService: createdSvc.body };
		await list(ctx);
	} catch (err) {
		console.error('error', err);
		ctx.body = err.message;
		ctx.status = 400;
	}
});

const getLogs = async (name, pod, io) => {
	streams[name] = new stream.PassThrough();
	streams[name].on('data', chunk => {
		// use write rather than console.log to prevent double line feed
		// process.stdout.write('workspace/' + name + '      ' + chunk);
		io.of('/hedej')
			.in('workspace/' + name)
			.emit('log', { room: 'workspace/' + name, time: chunk.toString().split(' ')[0], type: 'log', log: chunk.toString().split(' ').slice(1).join(' ') });
	});

	const containerName = pod.spec.containers[0].name;
	// console.log(foundPod.spec);
	try {
		log
			.log(NAMESPACE, pod.metadata.name, containerName, streams[name], {
				follow: true,
				tailLines: 50,
				pretty: true,
				timestamps: true,
			})
			.catch(e => {
				console.log(e);
				io.of('/hedej')
					.in('workspace/' + name)
					.emit('log', { room: 'workspace/' + name, time: new Date().toISOString(), type: 'status', log: `Workspace ${'workspace/' + name} was closed` });
			});
	} catch (e) {
		console.error('error log ', e);
	}
};

const watchPod = async (name, io) => {
	// console.log('watch pod', name);
	// for (let i = 0; i < 5; i++) {
	// 	const podsRes = await k8sApi.listNamespacedPod(NAMESPACE);
	// 	foundPod = podsRes.body.items.find(v => {
	// 		// console.log(v.metadata.name, name);
	// 		return v.metadata.name.startsWith(name);
	// 	});
	// 	console.log('foundPod', foundPod);
	// 	if (foundPod !== undefined) {
	// 		break;
	// 	}
	// 	await setTimeout(() => {}, 1000);
	// }

	const watch = new k8s.Watch(kc);
	watch.watch(
		`/api/v1/namespaces/${NAMESPACE}/pods`,
		{},
		(eventType, pod) => {
			if ((eventType === 'ADDED' || eventType === 'MODIFIED') && pod.metadata.name.startsWith(name)) {
				io.of('/hedej')
					.in('workspace/' + name)
					.emit('log', {
						room: 'workspace/' + name,
						time: new Date().toISOString(),
						type: 'status',
						log: `Job pod ${pod.metadata.name} added. ${pod.status.phase}`,
					});
				if (pod.status.phase === 'Succeeded' || pod.status.phase === 'Running') {
					getLogs(name, pod, io);
				} else if (pod.status.phase === 'Failed') {
					io.of('/hedej')
						.in('workspace/' + name)
						.emit('log', {
							room: 'workspace/' + name,
							time: new Date().toISOString(),
							type: 'status',
							log: `Workspace ${pod.metadata.name} failed.`,
						});
					console.error(`Job failed. Pod ${pod.metadata.name} status: ${pod.status.phase}.`, pod.status);
				}
			}
		},
		error => {
			throw new Error(error);
		},
	);
};

workspace.get('/watch', async ctx => {
	const { name } = ctx.query;
	watchPod(name, ctx.io);
	ctx.body = { result: 'ok' };
});

workspace.get('/list', list);

workspace.get('/:_id', ctx => {
	// #swagger.tags=['Workspace']
	console.log('aaa');
	ctx.body = 'aaa';
});

export default workspace;
