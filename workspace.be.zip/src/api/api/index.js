import Router from 'koa-router';
const api = new Router();

import swagger from "swagger2";
import { koaSwagger } from 'koa2-swagger-ui';

import auth from './auth/index.js';
import attachment from './attachment/index.js';
import mail from './mail/index.js';

import System from '../../models/system.js';
import kubernetes from './kubernetes/index.js';
import workspace from './workspace/index.js';
import database from './database/index.js';
import publish from './publish/index.js';
import template from './template/index.js';
import iam from './iam/index.js';
import project from './project/index.js';
import dns from './dns/index.js';
import setting from './setting/index.js';

const swaggerJson=swagger.loadDocumentSync('./swagger-output.json')

api.use('/auth', auth.routes());
api.use('/mail', mail.routes());
api.use('/attachment', attachment.routes());
api.use('/kubernetes', kubernetes.routes());
api.use('/workspace', workspace.routes());
api.use('/database',database.routes());
api.use('/project',project.routes());
api.use('/publish',publish.routes());
api.use('/iam', iam.routes());
api.use('/template',template.routes());
api.use('/dns',dns.routes());
api.use('/setting',setting.routes());
api.get('/health', ctx => {
	ctx.status = 200;
	return {};
});
api.get('/swagger',koaSwagger({routePrefix: false, swaggerOptions:{spec:swaggerJson}}));


export default api;
