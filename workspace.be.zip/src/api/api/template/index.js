import Router from 'koa-router';
import mongoose from 'mongoose';
import { injectUserToKC, k8sApi, k8sAppApi, kc, updateServices } from '../../../lib/kubeConfig.js';
import Template from '../../../models/workspace/template.js';
const template = new Router();

template.put('/', async ctx =>{
    /*
    #swagger.tags=['template']
    #swagger.path ='/api/template'
    #swagger.description='create new template to use in project',
    #swagger.parameters['body']={
        in:'body',
        description:'',
        schema:{
            name:'',
            type:'',
            version:''
        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            type:'',
            version:'',
            created:''

        }
    }
    */
   console.log("create template");
   if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let {body} = ctx.request;
    let template;
    try{
        template = await new Template(body).save();
    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body= template;
});
template.delete('/:_id', async ctx =>{
    /*
    #swagger.tags=['template']
    #swagger.path ='/api/template/{_id}'
    #swagger.description='delete existed template',
    #swagger.parameters['_id']= {description :'objectId of specific template to delete", required:true }
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            type:'',
            version:'',
            created:''

        }
    }
    */
    console.log("delete template")
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let {_id} = ctx.params;
    let deletedTemplate;

    try{    
        if(_id!==undefined){
            deletedTemplate = await Template.findByIdAndDelete(_id).exec();
        }

    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body= deletedTemplate;
});

export default template;