import Router from 'koa-router';
import {
	login,
	logout,
	check,
	list,
	find,
	getLocalUsersAndGroups,
	getGroups,
	getLocalUsers,
	get,
	update,
	finsert,
	updateGroups,
	oidcCallback,
} from './auth.ctrl.js';
import { isAdmin } from '../../../lib/admin.js';

const auth = new Router();

auth.get('/login', login);
auth.get('/logout', logout);
auth.get('/check', check);
auth.post('/callback', oidcCallback);
auth.get('/callback', oidcCallback);
auth.get('/user', list);
auth.get('/find', find);
auth.get('/findLocalUserAndGroup', getLocalUsersAndGroups);
auth.get('/findGroup', getGroups);
auth.get('/findLocalUser', getLocalUsers);
auth.get('/user/:userid', get);
auth.put('/update/:userid', isAdmin, update);
auth.post('/finsert', finsert);
auth.post('/updateGroup', updateGroups);

export default auth;
