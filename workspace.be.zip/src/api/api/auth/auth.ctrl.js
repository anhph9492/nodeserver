import axios from 'axios';
import System from '../../../models/system.js';
import User from '../../../models/user.js';
import user from '../../../models/workspace/user.js';

import { extractTokens, getLoginUrl } from '../../../lib/token.js';
import { uploadLocal } from '../attachment/attachment.ctrl.js';

// const nonce = generators.nonce();

const createLocalUser = async username => {
	const system = await System.find();
	const systemList = system.map(v => v.name);

	const { dn, description } = await global.ad.user(username).get();
	const groupList = dn
		.split(',')
		.filter(str => str.match('AV115A'))
		.map(group => group.replace(/[A-Z]+[=][A-Z0-9]+\./g, '').replace(/\([0-9]+\)/g, ''));
	const fullname = description;
	const payload = {
		userid: username,
		name: fullname,
		group: groupList[0],
		permission: {},
	};

	for (let name of systemList) {
		payload.permission[name] = 'user';
	}
	return new User(payload).save();
};

export const login = async ctx => {
	// #swagger.tags=['Auth']
	let { redirect } = ctx.query;

	try {
		const res = getLoginUrl();
		ctx.cookies.set('redirect', redirect);
		ctx.redirect(res);
	} catch (e) {
		console.error(e);
		ctx.staus = 500;
		return;
	}
};

/**
 * /api/auth/logout
 */
export const logout = async ctx => {
	// #swagger.tags=['Auth']
	ctx.cookies.set('workspace_session_token', null);
	ctx.cookies.set('workspace_rft', null);
	ctx.cookies.set('workspace_userinfo', null);
	ctx.status = 204;
};

/**
 * /api/auth/callback
 */
export const oidcCallback = async ctx => {
	// #swagger.tags=['Auth']


	try {
		const { refreshToken, idToken, userinfo } = await extractTokens(ctx);
		console.log("refreshTok >> ",refreshToken)
		console.log("idTok >> ", idToken)
		console.log("userinfo >> ",userinfo)
		ctx.cookies.set('workspace_session_token', idToken);
		ctx.cookies.set('workspace_rft', refreshToken);
		ctx.cookies.set('workspace_userinfo', Buffer.from(JSON.stringify(userinfo)).toString('base64'));
		const redirect = ctx.cookies.get('redirect');
		console.log("redirect >> ",redirect)
		ctx.cookies.set('redirect', null);
		ctx.redirect(redirect || '/');
		let oidcUser = await user.findOne({sub:userinfo.sub}).lean();
		console.log("oidcUser 1  >> ",oidcUser)
		if(oidcUser !== null && oidcUser !==undefined){
			oidcUser = await user.findOneAndUpdate({sub:userinfo.sub},{...userinfo,idToken:idToken })
			console.log("oidcUser 2  >> ",oidcUser)
		}else{
			try{
				oidcUser= await new user({...userinfo, idToken}).save();
				console.log("oidcUser 3  >> ",oidcUser)
			}catch(e){
				console.error(e);
				console.log("error 1 ")
				ctx.status=500;
			}
		}
	} catch (e) {
		console.error(e);
		ctx.status = 500;
		console.log("error 2")
		return;
	}
};

/**
 * /api/auth/check
 */
export const check = async ctx => {
	if (ctx.request.user !== undefined) {
		ctx.body = ctx.request.user;
		ctx.status = 200;
	} else {
		ctx.status = 403;
	}
};

// export const grantSSOAccount = async ctx => {
// 	let { sso } = ctx.request;

// 	try {
// 		if (sso) {
// 			let users = await User.find({ userid: sso.ssoid });

// 			let user = users[0];

// 			if (users.length === 0) {
// 				const adQuery = await global.ad.user(sso.ssoid).get();
// 				console.log(adQuery);
// 				const { dn, description, mail } = adQuery;
// 				const groupList = dn
// 					.split(',')
// 					.filter(str => str.match('AV115A'))
// 					.map(group => group.replace(/[A-Z]+[=][A-Z0-9]+\./g, '').replace(/\([0-9]+\)/g, ''));
// 				const fullname = description;
// 				const payload = {
// 					userid: sso.ssoid,
// 					name: fullname,
// 					mail,
// 					group: groupList[0],
// 					permission: {},
// 				};
// 				user = await new User(payload).save();
// 			}

// 			if (user !== undefined) {
// 				user.empno = sso.empno;
// 				user.encodedPw = sso.pw;
// 				if (user.profilePhoto === undefined) {
// 					const photo = await axios.get('http://hrportal.lge.com:6080/HRIS/common/commonNavi/retrievePerImages.dev?employee_number=' + sso.empno, {
// 						responseType: 'arraybuffer',
// 						headers: { 'Content-Type': 'image/png' },
// 					});
// 					const fileResult = await uploadLocal({
// 						originalname: sso.empno + '.png',
// 						buffer: Buffer.from(photo.data),
// 					});
// 					user.profilePhoto = fileResult._id;
// 				}
// 				await user.save();

// 				const jsonUser = user.toObject();
// 				delete jsonUser.encodedPw;
// 				ctx.body = jsonUser;
// 			}
// 		}
// 	} catch (e) {
// 		ctx.throw(500, e);
// 	}

// 	ctx.status = 200;
// };

export const list = async ctx => {
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	let users;
	let count;

	try {
		users = await User.find().exec();
		count = await User.countDocuments().exec();
	} catch (e) {
		return ctx.throw(500, e);
	}

	ctx.body = {
		documents: users,
		total: count,
		startAt: 0,
	};
};

export const get = async ctx => {
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	let { userid } = ctx.params;
	let users;

	try {
		users = await User.find({ userid: userid }).exec();
	} catch (e) {
		return ctx.throw(500, e);
	}

	if (!user) {
		ctx.status = 404;
		ctx.body = { message: 'user not found' };
		return;
	}

	ctx.body = users;
};

export const getLocalUsersAndGroups = async ctx => {
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	let { keyword } = ctx.query;
	if (keyword === undefined) {
		keyword = '';
	}

	let users;
	const query = {
		$or: [{ userid: { $regex: keyword, $options: 'i' } }, { name: { $regex: keyword, $options: 'i' } }, { groupid: { $regex: keyword, $options: 'i' } }],
	};
	try {
		users = await User.find(query).populate({ path: 'members', strictPopulate: false }).exec();
	} catch (e) {
		return ctx.throw(500, e);
	}

	if (!user) {
		ctx.status = 404;
		ctx.body = { message: 'user not found' };
		return;
	}

	ctx.body = users;
};

export const getGroups = async ctx => {
	let { user } = ctx.request;

	user = await User.findOne({ userid: user.userid }).lean();

	if (!user) {
		ctx.status = 403;
		return;
	}

	let { keyword } = ctx.query;
	if (keyword === undefined) {
		keyword = '';
	}

	let groups;
	const query = { groupid: { $exists: true } };
	try {
		groups = await User.find(query).populate({ path: 'members', strictPopulate: false }).lean();
		// console.log('groups', groups);
		ctx.body = groups.filter(group => group.members.map(u => u._id.toString()).includes(user._id.toString()));

		if (ctx.body.findIndex(u => u.name === 'System Admin') >= 0) {
			console.log('you are admin');
			ctx.body = groups.filter(group => group.groupid !== 'registered_user' && group.groupid !== 'anonymous_user');
		}
	} catch (e) {
		return ctx.throw(500, e);
	}
};

export const updateGroups = async ctx => {
	let { body, user } = ctx.request;
	user = await User.findOne({ userid: user.userid }).lean();

	if (!user) {
		ctx.status = 403;
		return;
	}

	let created;
	if (body._id !== undefined) {
		try {
			created = await User.findOneAndUpdate({ _id: body._id }, body, {
				upsert: true,
			});
		} catch (e) {
			return ctx.throw(500, e);
		}
	} else {
		try {
			created = new User({ ...body, members: [user._id] }).save();
		} catch (e) {
			return ctx.throw(500, e);
		}
	}
	ctx.body = created;
};

export const getLocalUsers = async ctx => {
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	let { keyword } = ctx.query;
	if (keyword === undefined) {
		keyword = '';
	}

	let users;
	const query = {
		$and: [
			{
				$or: [{ name: { $regex: keyword, $options: 'i' } }, { userid: { $regex: keyword, $options: 'i' } }],
			},
			{ groupid: { $exists: false } },
		],
	};
	try {
		users = await User.find(query).exec();
	} catch (e) {
		return ctx.throw(500, e);
	}

	if (!user) {
		ctx.status = 404;
		ctx.body = { message: 'user not found' };
		return;
	}

	ctx.body = users;
};

export const find = async ctx => {
	const { user } = ctx.query;
	// const ad = new ActiveDirectory(configActiveDirectory);

	let result = null;
	try {
		const users = await global.ad.find(`|(displayName=${user}*)(mail=${user}*)`);
		if (users.length !== 0) {
			result = users.users;
			if (result.length > 10) {
				result = result.slice(1, 10);
			}
		}
	} catch (e) {
		return ctx.throw(500, e);
	}
	ctx.body = result;
};

export const update = async ctx => {
	const { user, admin } = ctx.request;
	const { system, group } = ctx.request.body;

	if (!user) {
		ctx.status = 403;
		return;
	}

	if (!admin.includes(user.userid)) {
		ctx.status = 403;
		return;
	}

	const { userid } = ctx.params;

	if (!userid) {
		ctx.status = 400;
		return;
	}

	const userInfo = await User.find({ userid: userid });
	const update = { permission: { ...userInfo[0].permission, [system]: group } };

	let users;

	try {
		const usersCurrent = await User.find({ userid: userid });
		const usersUpdated = await User.findOneAndUpdate({ userid: userid }, update, { new: true });
	} catch (e) {
		return ctx.throw(500, e);
	}

	ctx.body = users;
};

export const finsert = async ctx => {
	const { user } = ctx.request;
	// const ad = new ActiveDirectory(configActiveDirectory);

	if (!user) {
		ctx.status = 403;
		return;
	}
	let userInfo;
	if (userInfo === null || userInfo?.userid === undefined) {
		const userFull = ctx.request.body;

		const system = await System.find();
		const systemList = system.map(v => v.name);

		const { dn, description } = await global.ad.user(userFull.userid).get();
		const groupList = dn
			.split(',')
			.filter(str => str.match('AV115A'))
			.map(group => group.replace(/[A-Z]+[=][A-Z0-9]+\./g, '').replace(/\([0-9]+\)/g, ''));
		const fullname = description;
		const payload = {
			...userFull,
			name: fullname,
			group: groupList[0],
			permission: {},
		};

		for (let name of systemList) {
			payload.permission[name] = 'user';
		}

		userInfo = await new User(payload).save();
		console.log('created new user', userInfo, ctx.request.body);
	}

	ctx.body = userInfo;
};
