import Router from 'koa-router';
import mongoose from 'mongoose';
import { injectUserToKC, k8sApi, k8sAppApi, kc, updateServices } from '../../../lib/kubeConfig.js';
import Dns from '../../../models/workspace/dns.js'
const dns = new Router();

dns.put('/', async ctx=>{
    /*
    #swagger.tags=['dns']
    #swagger.path ='/api/dns'
    #swagger.description='create new Dns with several options'
    #swagger.parameters['body']={
        in: 'body',
        description:'',
        schema:{
            url:'',
            ip:'',
            cert:'',
            firedDate:'',
            connectedPublish:'',
            key:''

        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            ip:'',
            url:'',
            cert:'',
            key:'',
            firedData:'',
            connectedPublish:'',
            created:'',
            lastModified:''
        }
    }
    */
    console.log("create dns")
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { body }= ctx.request;
    let dns;
    try{
        dns= await new Dns(body).save();
    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body= dns;
});
dns.get('/all',async ctx=>{
    /*
     #swagger.tags=['dns']
     #swagger.path ='/api/dns/all'
     #swagger.description='retrieve all dns in workspace'
     #swagger.responses[200]={
         description:'',
         schema:[
             {
             _id:'',
             ip:'',
             url:'',
             cert:'',
             firedDate:'',
             connectedPublish:'',
             key:'',
             created:'',
             lastModified:''
         }
         ]
     }
     */
     let {user }= ctx.request;
     if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
         ctx.status = 403;
         return;
     }
     let allDns;
     try{
         allDns= await Dns.find().sort({created:1}).exec();
     }catch(e){
         ctx.throw(500,e);
     }
     ctx.body=allDns;
 });
dns.get('/:_id', async ctx=>{
    /*
    #swagger.tags=['dns']
    #swagger.path ='/api/dns/{_id}'
    #swagger.description='get specific dns information in workspace'
    #swagger.parameters['_id']={required:true, description:'ObjectId of specific dns'}
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            ip:'',
            url:'',
            cert:'',
            firedDate:'',
            connectedPublish:'',
            key:'',
            created:'',
            lastModified:''
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let {_id}= ctx.params;
    let dns;
    try{
        dns= await Dns.findById(_id).sort({created:1}).exec();
    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body = dns;
});
dns.post('/:_id', async ctx=>{
    /*
    #swagger.tags=['dns']
    #swagger.path ='/api/dns/{_id}'
    #swagger.description='update specific dns with updated data'
    #swagger.parameters['_id']={required:true, description:'ObjectId of specific dns to update some values'}
    #swagger.parameters['body']={
        in: 'body',
        description:'',
        schema:{
            url:'',
            ip:'',
            cert:'',
            firedDate:'',
            connectedPublish:'',
            key:''
        }
    }
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            ip:'',
            url:'',
            cert:'',
            key:'',
            firedDate:'',
            connectedPublish:'',
            created:'',
            lastModified:''
        }

    }
    */
    console.log("update dns",ctx.params)
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { body }= ctx.request;
    let updated;
    let {_id}= ctx.params;
    try{
        updated = await Dns.findOneAndUpdate({_id:_id},{...body, lastModified:Date.now()},{new:true, upsert:true});
    }catch(e){
        return ctx.throw(500,e)
    }
    ctx.body = updated;
});
dns.delete('/:_id', async ctx=>{
    /*
    #swagger.tags=['dns']
    #swagger.description='delete specific dns'
    #swagger.path ='/api/dns/{_id}'
    #swagger.parameters['_id']={required:true, description:'ObjectId of specific dns to remove'}
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            ip:'',
            url:'',
            cert:'',
            key:'',
            firedDate:'',
            connectedPublish:'',
            created:'',
            lastModified:''
        }
    }
    */
    console.log("delete dns")
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let {_id} = ctx.params;
    let deletedDns;

    try{    
        if(_id!==undefined){
            deletedDns = await Dns.findByIdAndDelete(_id).exec();
        }

    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body= deletedDns;
});

export default dns;