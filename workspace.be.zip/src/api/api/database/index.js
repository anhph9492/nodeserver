import Router from 'koa-router';
import mongoose from 'mongoose';
import k8s from '@kubernetes/client-node';
import { injectUserToKC, k8sApi, k8sAppApi, kc, updateServices , metricsClient} from '../../../lib/kubeConfig.js';
import Database from '../../../models/workspace/database.js'
const database = new Router();
import mongodb from '../workspace/mongodb/index.js';
const NAMESPACE = 'workspace';
database.put('/',async ctx=>{
    /*
    #swagger.tags=['database']
    #swagger.path = '/api/database'
    #swagger.description="create database in workspace"

    #swagger.parameters['body'] = {
        in: 'body',
        description: "name type can contain - or . , and must start and end with an alphanumeric character",
        schema: {
            databaseType:'mongoDB',
            storage:'',
            name:'',
            cpu:'',
            memory:'',
            storage:'10Gi',
            iamName:'',
            workspaceId:'xxxxx'
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema: {
            _id:'',
            name:'',
            databaseID:'',
            storage:'',
            databasePWD:'',
            storage:'10Gi',
            cpu:'',
            memory:'',
            podName:[],
            iamName:'',
            workspaceId:'',
            created:'',
            lastModified:''
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { body } = ctx.request;
    let selectedDB;

    if(body.databaseType==='mongoDB' || body?.databaseType ===undefined ){
        selectedDB=mongodb;
    }
    const statefulset = selectedDB.getStatefulSet({name:body.name, databaseType:body.databaseType, storage:body.storage});
	const svc = selectedDB.getService({name:body.name, databaseType:body.databaseType});
    const secret=selectedDB.getSecret({secretName:`secret-${body.name}`, namespace:NAMESPACE});
    let createdSecret, createdStatefulSet, createdSvc;
    
    let newDatabase;
    try{
        let stfName;
        createdStatefulSet = await k8sAppApi.createNamespacedStatefulSet(NAMESPACE,statefulset).then((res)=>{stfName=res.body.metadata.name;}).catch(e=>{
            const err = new Error();
            err.message = e.body;
            throw err;
        });
        createdSecret = await k8sApi.createNamespacedSecret(NAMESPACE, secret).catch(e => {
            const err = new Error();
            err.message = e.body;
            throw err;
        });
		createdSvc = await k8sApi.createNamespacedService(NAMESPACE, svc).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});
        const watch = new k8s.Watch(kc);
        const topPodsRes = await k8s.topPods(k8sApi, metricsClient, NAMESPACE);
        const podsColumns = topPodsRes.map((pod) => {
            let curpodname=pod.Pod.metadata.name;
            let lastIndex = curpodname.lastIndexOf('-');
            let substring;
            if (lastIndex !== -1) {
                substring= curpodname.substring(0, lastIndex);
            }
            if(substring === stfName)
            {
                return curpodname
            }else{
                return null
            }
        }).filter(item => item !== null);
        newDatabase=await new Database({...body,podName:podsColumns}).save();
    }catch(e){
        return ctx.throw(500,e);
    }
    ctx.body=newDatabase;
    return newDatabase;
});
database.get('/all', async ctx=>{
    /* #swagger.tags=['database']
    #swagger.description="list all database in workspace"
    #swagger.path = '/api/database/all'
    #swagger.responses[200]={
        description:'',
        schema:[{
            _id:'',
            databaseType:'',
            name:'',
            storage:'',
            cpu:'',
            memory:'',
            iamName:'',
            databaseId:'',
            databasePwd:'',
            podName:[],
            created:'',
            lastModified:'',
            Current_CPU_cores:'',
            Current_MEMORY_bytes:''
        }]

    }
    */
    const { user, query } = ctx.request;

    let databases, mergedDatabases;
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}
    try{
        databases=await Database.find().sort({created:1}).exec();
        const topPodsRes = await k8s.topPods(k8sApi, metricsClient, NAMESPACE);
        const podsColumns = topPodsRes.map((pod) => {
            return {
                podName: pod.Pod.metadata.name,
                'Current_CPU_cores': pod.CPU.CurrentUsage.toString(),
                'Current_MEMORY_bytes': pod.Memory.CurrentUsage.toString(),
            };
        });
        mergedDatabases = databases.map(item1 => {
            let matchedPod = podsColumns.find(item2 => {
                if (Array.isArray(item1._doc.podName)) {
                    return item1._doc.podName.some(name => name === item2.podName);
                } else {
                    return item2.podName === item1._doc.podName;
                }
            });
        
            return {
                ...item1._doc,
                ...matchedPod
            };
        });
    }catch(e){

    }
    ctx.body=mergedDatabases;
    
});
database.get('/:_id', async ctx=>{
    /* #swagger.tags=['database']
    #swagger.description="get specific database in workspace"
    #swagger.path = '/api/database/{_id}'
    #swagger.parameters['_id']= {description :'objectId of specific database", required:true }
    
    #swagger.responses[200]={
        description:'',
        schema: [{
            _id:'',
            databaseType:'',
            name:'',
            storage:'',
            cpu:'',
            memory:'',
            iamName:'',
            databaseId:'',
            databasePwd:'',
            podName:[],
            created:'',
            lastModified:'',
            Current_CPU_cores:'',
            Current_MEMORY_bytes:''
        }]
    }
    */
    const { _id } = ctx.params;
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}

    let database, podsColumns;
    try{
        if(_id!==undefined){
            database=await Database.findById(_id).sort({created:1});
        }
        const topPodsRes = await k8s.topPods(k8sApi, metricsClient, NAMESPACE);
        podsColumns = topPodsRes.filter(pod => {
            if (Array.isArray(database.podName)) {
                return database.podName.includes(pod.Pod.metadata.name);
            } else {
                return pod.Pod.metadata.name === database.podName;
            }
        }).map(pod => {
            return {
                'Current_CPU_cores': pod.CPU.CurrentUsage.toString(),
                'Current_MEMORY_bytes': pod.Memory.CurrentUsage.toString(),
                ...database?._doc
            };
        });
    }catch(e){
        return ctx.throw(500,e);
    }
    ctx.body=podsColumns;
    return podsColumns;


});
database.delete('/:_id', async ctx=>{
    /*
    #swagger.tags=['database']
    #swagger.description="delete database in workspace"
    #swagger.parameters['_id']= {description :'objectId of specific database", required:true }
    #swagger.path = '/api/database/{_id}'
    #swagger.responses[200]={
        description:'',
        schema: {
            _id:'',
            databaseID:'',
            databasePWD:'',
            usedStorage:'',
            cpu:'',
            memory:'',
            iamName:'',
            workspaceId:'',
            created:'',
            lastModified:'',
            podName:[],
        }
    }
    */
    const { _id }=ctx.params;
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status=403;
    }
    let selectedDB;
    let deletedDatabase;
    
    try{
        deletedDatabase = await Database.findById(_id).exec();
        if(deletedDatabase.databaseType ==='mongoDB' || deletedDatabase.databaseType === undefined){
            selectedDB=mongodb;
        }
        const statefulset = selectedDB.getStatefulSet({name:deletedDatabase.name, databaseType:deletedDatabase.databaseType, storage:deletedDatabase.storage});
        const svc = selectedDB.getService({name:deletedDatabase.name, databaseType:deletedDatabase.databaseType});
        const secret=selectedDB.getSecret({secretName:`secret-${deletedDatabase.name}`, namespace:NAMESPACE});
        let deletedStatefulSet, deletedSvc, deletedSecret;
        deletedStatefulSet = await k8sAppApi.deleteNamespacedStatefulSet(statefulset.metadata.name,NAMESPACE).catch(e=>{
            const err = new Error();
            err.message = e.body;
            throw err;
        });
        deletedSecret = await k8sApi.deleteNamespacedSecret(secret.metadata.name, NAMESPACE).catch(e => {
            const err = new Error();
			err.message = e.body;
			throw err;
		});
        deletedSvc = await k8sApi.deleteNamespacedService( svc.metadata.name ,NAMESPACE).catch(e => {
            const err = new Error();
            err.message = e.body;
            throw err;
        });
        deletedDatabase = await Database.findByIdAndDelete(_id).exec();
    }catch(e){
        return ctx.throw(500,e)
    }
    ctx.body = deletedDatabase;
});

export default database;