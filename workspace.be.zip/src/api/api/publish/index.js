import Router from 'koa-router';
import mongoose from 'mongoose';
import { injectUserToKC, k8sApi, k8sAppApi, kc, updateServices } from '../../../lib/kubeConfig.js';
import Publish from '../../../models/workspace/publish.js';

const publish = new Router();

publish.put('/', async ctx=>{
    /*
    #swagger.tags=['publish']
    #swagger.description='create new publish in workspace with several options' 
    #swagger.path ='/api/publish'
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            projectId:'',
            date:'',
            version:'',
            containerName:'',
            contaminerVersion:'',
            dnsId:''
        }
    } 
    #swagger.response[200]={
        description:'',
        schema:{
            _id:'',
            containerName:'',
            containerVersion:'',
            date:'',
            version:'',
            dnsId:'',
            status:'',
            author:[]
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { body}= ctx.request;
    let publish;
    try{
        publish= await new Publish(body).save();

    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body=publish

});
publish.get('/all',async ctx=>{
    /*
    #swagger.tags=['publish']
    #swagger.description='list all publish in workspace' 
    #swagger.path ='/api/publish/all'
    #swagger.response[200]={
        description:'',
        schema:[
            {
            _id:'',
            containerName:'',
            containerVersion:'',
            date:'',
            version:'',
            dnsId:'',
            status:'',
            author:[]
        }
        ]
    }
    */
    console.log("listAll")

    const { user, query } = ctx.request;
    let publish;
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}
    try{
        publish=await Publish.find({$or:[{author:{$in : [user]}},{owner:{$in:[user]}}]}).sort({created:1}).exec();
    }catch(e){

    }
    ctx.body= publish;
});
publish.get('/:_id', async ctx=>{
    /*
    #swagger.tags=['publish']
    #swagger.path ='/api/publish/{_id}'
    #swagger.description='list specific publish in workspace' 
    #swagger.parameters['_id']= {description :'objectId of specific publish", required:true }
    #swagger.response[200]={
        description:'',
        schema:{
            _id:'',
            containerName:'',
            containerVersion:'',
            date:'',
            version:'',
            dnsId:'',
            status:'',
            author:[]
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    const {_id}= ctx.params;
    let publish;
    try{
        if(_id!==undefined){
            publish= await Publish.findById(_id).sort({created:1}).exec();
        }
    }catch(e){
        return ctx.throw(500,e);
    }
    ctx.body=publish;
});
publish.post('/start/:_id', async ctx=>{

    /*
    #swagger.tags=['publish']
    #swagger.description='start specific publish' 
    #swagger.path ='/api/publish/start/{_id}'
    #swagger.parameters['_id']= {description :'objectId of specific publish to start", required:true }
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            version:''
        }
    } 
    #swagger.response[200]={
        description:'',
        schema:{
            _id:'',
            containerName:'',
            containerVersion:'',
            date:'',
            version:'',
            dnsId:'',
            status:'running',
            author:[]
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
});
publish.post('/stop/:_id', async ctx=>{
    /*
    #swagger.tags=['publish']
    #swagger.description='stop specific publish' 
    #swagger.path ='/api/publish/stop/{_id}'
    #swagger.parameters['_id']= {description :'objectId of specific publish to stop", required:true }
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            version:''
        }
    } 
    #swagger.response[200]={
        description:'',
        schema:{
            _id:'',
            containerName:'',
            containerVersion:'',
            date:'',
            version:'',
            dnsId:'',
            status:'stop',
            author:[]
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }

});
publish.post('/rollback/:_id',async ctx=>{
    /*
    #swagger.tags=['publish']
    #swagger.path ='/api/publish/rollback/{_id}'
    #swagger.description='rollback specific publish' 
    #swagger.parameters['_id']= {description :'objectId of specific version of publish to rollback", required:true }
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            version:''
        }
    } 
    #swagger.response[200]={
        description:'',
        schema:{
            _id:'',
            containerName:'',
            containerVersion:'',
            date:'',
            version:'',
            dnsId:'',
            status:'',
            author:[]
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
});
publish.delete('/:_id', async ctx=>{
    /*
     #swagger.tags=['publish']
     #swagger.path ='/api/publish/{_id}'
     #swagger.description='delete specific publish' 
     #swagger.parameters['_id']= {description :'objectId of specific version of publish to delete", required:true }
     #swagger.response[200]={
         description:'',
         schema:{
             _id:'',
             containerName:'',
             containerVersion:'',
             date:'',
             version:'',
             dnsId:'',
             status:'deleted',
             author:[]
         }
     }
     */
     if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
         ctx.status = 403;
         return;
     }
 });

export default publish;