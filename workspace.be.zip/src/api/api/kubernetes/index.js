import Router from 'koa-router';
import k8s from '@kubernetes/client-node';
const kubernetes = new Router();

const kc = new k8s.KubeConfig();
kc.loadFromDefault();

const k8sApi = kc.makeApiClient(k8s.CoreV1Api);

kubernetes.get('/', async ctx => {
	try {
		const podsRes = await k8sApi.listNamespacedPod('default');
		// console.log(podsRes.body);
		ctx.body = podsRes.body;
	} catch (err) {
		console.error(err);
	}
});

kubernetes.get('/:_id', ctx => {
	console.log('aaa');
	ctx.body = 'aaa';
});

export default kubernetes;
