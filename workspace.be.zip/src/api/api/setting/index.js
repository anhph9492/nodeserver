import Router from 'koa-router';
import Setting from '../../../models/workspace/setting.js';

const setting = new Router();

setting.put('/',async ctx=>{
    /*
    #swagger.tags=['setting']
    #swagger.description="create default setting when new user added"
    #swagger.path = '/api/setting'
    #swagger.parameters['body'] = {
        in: 'body',
        description: "",
        schema: {
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema: {
            _id:'',
            gitAuthorName:'',
            gitAuthorEmail:'',
            timezone:'',
            language:'',
            gitlabToken:'',
            theme:'light',
            created:'2023-11-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */
   let mysetting;
   try{
        mysetting = await new Setting().save();
   }catch(e){
        ctx.throw(500,e);
   }
   ctx.body=mysetting;
   return mysetting;
});

setting.get('/:_id',async ctx=>{
    /*
    #swagger.tags=['setting']
    #swagger.description="list setting information"
    #swagger.parameters['_id']= {description :'objectId of user", required:true }
    #swagger.path = '/api/setting/{_id}'
    #swagger.responses[200]={
        description:'',
        schema: {
            _id:'',
            gitAuthorName:'',
            gitAuthorEmail:'',
            timezone:'',
            language:'',
            gitlabToken:'',
            theme:'',
            created:'2023-11-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */
    const { _id } = ctx.params;
    let mysetting;
    try{
        if(_id !==undefined){
            mysetting= await Setting.findById(_id).sort({created:1});
        }
    }catch(e){
        return ctx.throw(500,e)
    }
    ctx.body=mysetting;
    return mysetting;
});

setting.post('/:_id',async ctx=>{
    /*
    #swagger.tags=['setting']
    #swagger.description="update existed setting data with some data in body"
    #swagger.parameters['_id']= {description :'objectId of specific database", required:true }
    #swagger.path = '/api/setting'
    #swagger.parameters['body'] = {
        in: 'body',
        description: "",
        schema: {
            gitAuthorName:'',
            gitAuthorEmail:'',
            timezone:'',
            language:'',
            gitlabToken:'',
            theme:'',
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema: {
            _id:'',
            gitAuthorName:'',
            gitAuthorEmail:'',
            timezone:'',
            language:'',
            gitlabToken:'',
            theme:'',
            created:'2023-11-23T04:08:48.312+00:00',
            lastModified:'2023-11-23T04:08:48.312+00:00'
        }
    }
    */
    const { _id } = ctx.params;
    let { body } = ctx.request;
    let mysetting;
    try{
        mysetting= await Setting.findByIdAndUpdate(_id,{...body, lastModified:Date.now()},{upsert:true, returnDocument: 'after'})
    }catch(e){
        return ctx.throw(500,e);
    };

    ctx.body=mysetting;
    return mysetting;
});

export default setting;