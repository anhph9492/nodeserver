import Router from 'koa-router';
import mongoose from 'mongoose';
import axios from '../../../../node_modules/axios/index.js';
import { injectUserToKC, k8sApi, k8sAppApi, kc, updateServices } from '../../../lib/kubeConfig.js';
import Project from '../../../models/workspace/project.js'
const project = new Router();
const NAMESPACE = 'workspace';
import codeserver from '../workspace/codeserver/index.js'
import jupyter from '../workspace/jupyter/index.js'

project.put('/', async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.description='create new project in workspace with several options' 
    #swagger.path ='/api/project'
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            cejCategory:[],
            dejCategory:[],
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            status:'',
            cejCategory:[],
            dejCategory:[],
        }
    }
    #swagger.responses[500]={
        description:'create new Project failed',
        schema:{
            
        }
    }
    */
    console.log("create project",ctx.request?.user ,ctx.request.body.user,ctx);
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let {body}=ctx.request;
    let selectedIde=codeserver;

    const newProject = new Project({...body});
    const deployment = selectedIde.getDeployment({ workspace: { name:body.name, version: 'latest', namespace: NAMESPACE } });
	const pvc = selectedIde.getPvc({ workspace: { name:body.name } });
	const svc = selectedIde.getService({ workspace: { name:body.name } });
    let createdDeployment, createdPvc, createdSvc;
    let newProjectId;
    try{
        await newProject.save();
        newProjectId=newProject?._id;
        createdDeployment = await k8sAppApi.createNamespacedDeployment(NAMESPACE, deployment).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		createdPvc = await k8sApi.createNamespacedPersistentVolumeClaim(NAMESPACE, pvc).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		createdSvc = await k8sApi.createNamespacedService(NAMESPACE, svc).catch(e => {
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		ctx.body = { createdDeployment: createdDeployment.body, createdPvc: createdPvc.body, createdService: createdSvc.body };
    }catch(e){
        if(newProjectId!==undefined){
            await Project.findByIdAndDelete(newProjectId).exec();
        }
        return ctx.throw(500,e);
    }
});
project.get('/all',async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.path ='/api/project/all'
     #swagger.description='retrieve all project in workspace'
     #swagger.responses[200]={
        description:'',
        schema:[
            {
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            status:'',
            cejCategory:[],
            dejCategory:[],
        }
        ]
    }
    */
    console.log("listAll")

    const { user, query } = ctx.request;
    let projects;
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
		ctx.status = 403;
		return;
	}
    try{
        projects=await Project.find().sort({created:1}).exec();
    }catch(e){
        return ctx.throw(500,e);
    }
    ctx.body= projects;
});
project.get('/', async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.path ='/api/project/'
    #swagger.description='retrieve specific project in workspace'
    #swagger.parameters['_id']= { in:'query', description :'objectId of specific project"}
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            status:'',
            cejCategory:[],
            dejCategory:[],
        }
    }
    #swagger.parameters['name']={
        in:'query',
        description:'specific name of project for retrieving',
        type:'string'
    }
    #swagger.responses[500]={
        description:'retrieve specific project failed',
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    const {name, _id}= ctx.query;
    let project;
    try{
        if(_id!==undefined){
            project= await Project.findById(_id).sort({created:1}).exec();
        }else{
            const nameRegex = new RegExp(`.*${name}.*`);
            project= await Project.find({name:{$regex:nameRegex}}).exec();
        }
    }catch(e){
        return ctx.throw(500,e);
    }
    ctx.body=project;
    return project
});
project.post('/', async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.description='update specific project in workspace'
    #swagger.path ='/api/project'
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            name:'',
            description:'',
            iamName:'',
            storage:'',
            databaseId:'',
            cejCategory:[],
            dejCategory:[],
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            cejCategory:[],
            dejCategory:[],
            status:''
        }
    }
    */
    let { body, user }= ctx.request;
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { name, _id }= ctx.query;
    let updatedProject;
    if(_id!==undefined){
        updatedProject = await Project.findById(_id).exec();
    }else if(name!==undefined){
        updatedProject = await Project.findOne({name}).exec();
    }
    let selectedIde=codeserver;
    
    let pvc = selectedIde.getPvc({ workspace: { name:updatedProject?.name, version: 'latest', namespace: NAMESPACE } });
    pvc.spec.resources.requests.storage='10Gi';
    await k8sApi.patchNamespacedPersistentVolumeClaim(pvc.metadata.name,pvc.metadata.namespace,{...pvc}).catch(e=>{
        const err= new Error();
        err.message= e.body;
        console.log(err.message)
        throw err;
    })
    // let updatedProject
    // if(body._id!==undefined){
    //     try{
    //         updatedProject=await Project.findOneAndUpdate({_id:body._id},body,{upsert:true});
    //     }catch(e){
    //         return ctx.throw(500,e);
    //     }
    // }else{
    //     try{
    //         updatedProject=new Project({...body}).save();
    //     }catch(e){
    //         return ctx.throw(500,e);
    //     }
    // }
    // ctx.body=updatedProject;
});
project.post('/share/:_id', async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.path ='/api/project/share/{_id}'
    #swagger.description='share specific project in workspace for added author'
    #swagger.parameters['_id']= {description :'objectId of specific project for sharing", required:true }
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            name:'',
            description:'',
            iamName:'',
            storage:'',
            databaseId:'',
            cejCategory:[],
            dejCategory:[],
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            status:'',
            cejCategory:[],
            dejCategory:[],
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { body }= ctx.request;
    let { _id }=ctx.params;

    let sharedProject;
    try{
        sharedProject= new Project(body);
        await sharedProject.save();
    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body=sharedProject;

});
project.post('/fork/:_id', async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.path ='/api/project/fork/{_id}'
    #swagger.description='fork specific project in workspace for new owner & author'
    #swagger.parameters['_id']= {description :'objectId of specific project for forking", required:true }
    #swagger.parameters['body'] = {
        in: 'body',
        description: 'Some description...',
        schema: {
            name:'',
            description:'',
            iamName:'',
            storage:'',
            databaseId:'',
            cejCategory:'[]
            dejCategory:[],
        }
    } 
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            status:'',
            cejCategory:[],
            dejCategory:[],
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    }
    let { body }= ctx.request;
    let { _id }=ctx.params;

    let forkedProject;
    try{
        forkedProject= new Project(body);
        await forkedProject.save();
    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body=forkedProject;
});
project.delete('/', async ctx=>{
    /*
    #swagger.tags=['project']
    #swagger.path ='/api/project'
    #swagger.description='delete specific project in workspace'
    #swagger.parameters['_id']= {in:'query', description :'objectId of specific project" }
    #swagger.parameters['name']= {in:'query', description :'name of specific project" }
    #swagger.responses[200]={
        description:'',
        schema:{
            _id:'',
            name:'',
            description:'',
            iamName:'',
            storage:'',
            templateRef:'',
            databaseId:'',
            created:'',
            lastModified:'',
            status:'',
            cejCategory:[],
            dejCategory:[],
        }
    }
    #swagger.responses[500]={
        description:'delete specific Project failed',
        schema:{
            
        }
    }
    */
    if (ctx.request.user === undefined && !injectUserToKC(ctx)) {
        ctx.status = 403;
        return;
    };
    let {_id} = ctx.params;
    let { name }=ctx.query;

    let deletedProject;
    if(_id!==undefined){
        deletedProject = await Project.findById(_id).exec();
    }else{
        deletedProject = await Project.findOne({name}).exec();
    }

    let selectedIde= codeserver;

    const deployment = selectedIde.getDeployment({ workspace: { name:deletedProject?.name, version: 'latest', namespace: NAMESPACE } });
	const pvc = selectedIde.getPvc({ workspace: { name:deletedProject?.name, version: 'latest', namespace: NAMESPACE } });
	const svc = selectedIde.getService({ workspace: { name:deletedProject?.name, version: 'latest', namespace: NAMESPACE } });
	let createdDeployment, createdPvc, createdSvc;

    try{    
        if(_id!==undefined){
            deletedProject = await Project.findByIdAndDelete(_id).exec();
        }else{
            deletedProject = await Project.deleteOne({name});
        }

        createdDeployment = await k8sAppApi.deleteNamespacedDeployment(deployment.metadata.name, deployment.metadata.namespace).catch(e => {
			console.error(e);
			const err = new Error();
			err.message = e.body;
			throw err;
		});
		createdPvc = await k8sApi.deleteNamespacedPersistentVolumeClaim(pvc.metadata.name, pvc.metadata.namespace).catch(e => {
			console.error(e);
			const err = new Error();
			err.message = e.body;
			throw err;
		});

		createdSvc = await k8sApi.deleteNamespacedService(svc.metadata.name, svc.metadata.namespace).catch(e => {
			console.error(e);
			const err = new Error();
			err.message = e.body;
			throw err;
		});

    }catch(e){
        ctx.throw(500,e);
    }
    ctx.body= deletedProject;
});

export default project;