import Router from 'koa-router';

const Mail = new Router();
import nodemail from 'nodemailer';
const mailer = nodemail.createTransport({
	host: '156.147.1.150',
	port: 25,
	secure: false,
});

Mail.post('/send', async ctx => {
	//#swagger.tags=['mail']
	// var mail = {
	//     from: '"Fred Foo 👻" <foo@example.com>', // sender address
	//     to: 'bar@example.com', // list of receivers
	//     subject: 'Hello ✔', // Subject line
	//     text: 'Hello world?', // plain text body
	//     html: '<b>Hello world?</b>' // html body
	// };
	const { body, user } = ctx.request;
	const { from, to, cc, bcc, subject, content, attachment } = body;

	if (!user) {
		ctx.status = 403;
		return;
	}

	const mail = {
		from,
		to,
		cc,
		bcc,
		subject,
		attachment,
		html: content,
	};

	if (!from || !to || !subject || !content) {
		ctx.status = 400;
		ctx.body = 'Required fields are missing\n';
		return;
	}

	try {
		mailer.sendMail(mail);
	} catch (e) {
		ctx.throw(500, e);
	}

	ctx.status = 200;
});

export default Mail;
