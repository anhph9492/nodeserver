import Router from 'koa-router';

const websocket = new Router();

websocket.get('/ws', async ctx => {
	console.log(ctx, ctx.ws);
	if (!ctx.ws) return;
	const ws = await ctx.ws();
	/*
	 * Send a message to the socket
	 * @param content - The message's object
	 */
	// function sendMessage(content) {
	// 	ws.send(JSON.stringify(content))
	// ws.on('connection', (data) => {
	//   console.log(data)
	// })
	// }

	ws.on('message', message => {
		// 클라이언트로부터 메시지 수신 시
		console.log(message);
	});
	ws.on('error', err => {
		// 에러 발생 시
		console.error(err);
	});
	ws.on('close', () => {
		// 연결 종료 시
		console.log('클라이언트 접속 해제', ip);
		clearInterval(ws.interval);
	});

	ws.interval = setInterval(() => {
		if (ws.readyState === ws.OPEN) {
			ws.send('서버에서 클라이언트로 메시지를 보냅니다.');
		}
	}, 3000);
});

export default websocket;
