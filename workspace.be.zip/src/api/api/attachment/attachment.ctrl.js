import mongoose from 'mongoose';
import Attachment from '../../../models/attachment.js';
const { ObjectId } = mongoose.Types;
import stream from 'stream';

import mmm from 'mmmagic';
import mime from 'mime-types';
import { GridFSBucket, MongoClient } from 'mongodb';
const Magic = mmm.Magic;

const uri = 'mongodb://platz:platz@10.159.48.242:27017/platz?authMechanism=DEFAULT';

export const list = async ctx => {
	const { filename } = ctx.request.query;
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	let attachments = null;
	let count = null;
	try {
		if (filename) {
			attachments = await Attachment.find({ filename }).sort({ uploadDate: -1 }).exec();
		} else {
			attachments = await Attachment.find().sort({ uploadDate: -1 }).exec();
		}
		count = await Attachment.countDocuments().exec();
	} catch (e) {
		return ctx.throw(500, e);
	}

	ctx.body = {
		documents: attachments,
		total: count,
		startAt: 0,
	};
	ctx.status = 200;
};

export const get = async ctx => {
	const { _id } = ctx.params;
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	try {

		const client = new MongoClient(uri);
		await client.connect();

		const grid = new GridFSBucket(client.db('platz'), { bucketName: 'attachment' });

		const file = await grid.find({ _id: new ObjectId(_id) }).toArray();
		const { filename, length, contentType } = file[0];
		const downloadStream = grid.openDownloadStreamByName(filename);

		ctx.type = contentType;
		ctx.set('Content-Length', length);

		ctx.body = downloadStream;
		ctx.status = 200;
	} catch (e) {
		ctx.throw(500, e);
	}
};

export const uploadLocal = async file => {
	let contentType = mime.lookup(file.originalname);
	if (!contentType) {
		const magic = new Magic(mmm.MAGIC_MIME_TYPE);
		contentType = await detect(magic, file.buffer);
	}
	file.mimetype = contentType;

	const fileStream = bufferToStream(file.buffer);
	const client = new MongoClient(uri);
	await client.connect();

	const grid = new GridFSBucket(client.db('platz'), { bucketName: 'attachment' });

	const uploadStream = grid.openUploadStream(file.originalname, { contentType });
	fileStream.pipe(uploadStream);

	const { _id, filename } = await gridStreamEventEmitter(uploadStream, 'finish');
	return { _id, filename };
};

export const upload = async ctx => {
	const { files, user } = ctx.request;
	const success = [];

	if (!user) {
		ctx.status = 403;
		return;
	}

	const client = new MongoClient(uri);
	await client.connect();

	const grid = new GridFSBucket(client.db('platz'), { bucketName: 'attachment' });

	try {
		for (let file of files) {
			let contentType = mime.lookup(file.originalname);
			if (!contentType) {
				const magic = new Magic(mmm.MAGIC_MIME_TYPE);
				contentType = await detect(magic, file.buffer);
			}
			file.mimetype = contentType;

			const fileStream = bufferToStream(file.buffer);
			const uploadStream = grid.openUploadStream(file.originalname, { contentType });
			fileStream.pipe(uploadStream);

			const { _id, filename } = await gridStreamEventEmitter(uploadStream, 'finish');
			success.push({ _id, filename });
		}
	} catch (e) {
		ctx.throw(500, e);
	}

	ctx.body = success;
	ctx.status = 200;
};

export const overwrite = async ctx => {
	// #swagger.tags=['Attachment']
	// #swagger.summary = 'attachment uploadlocal'
	// #swagger.description = 'Some description...'
	//#swagger.responsess[500] = { description: 'Some description...' }
	//  #swagger.parameters['_id'] = { description: 'Some description...' }
	const { _id } = ctx.params;
	const { files, user } = ctx.request;
	const success = [];

	if (!user) {
		ctx.status = 403;
		return;
	}

	try {
		const client = new MongoClient(uri);
		await client.connect();

		const grid = new GridFSBucket(client.db('platz'), { bucketName: 'attachment' });

		const file = files[0];
		const targetFile = await grid.find({ _id: new ObjectId(_id) }).toArray();
		const { filename, contentType } = targetFile[0];

		grid.delete(ObjectId(_id));

		const uploadStream = grid.openUploadStreamWithId(ObjectId(_id), filename, { contentType });
		const fileStream = bufferToStream(file.buffer);
		fileStream.pipe(uploadStream);

		const uploaded = await gridStreamEventEmitter(uploadStream, 'finish');
		success.push({
			_id: uploaded._id,
			filename: uploaded.filename,
		});
	} catch (e) {
		ctx.throw(500, e);
	}

	ctx.status = 200;
	ctx.body = success;
};

export const download = async ctx => {
	const { _id } = ctx.params;
	const { user } = ctx.request;

	if (!user) {
		ctx.status = 403;
		return;
	}

	try {
		const client = new MongoClient(uri);
		await client.connect();

		const grid = new GridFSBucket(client.db('platz'), { bucketName: 'attachment' });
		const file = await grid.find({ _id: new ObjectId(_id) }).toArray();
		const { filename, length, contentType } = file[0];
		const downloadStream = grid.openDownloadStreamByName(filename);

		ctx.type = contentType;
		ctx.attachment(filename);
		ctx.set('Content-Length', length);

		ctx.body = downloadStream;
		ctx.status = 200;
	} catch (e) {
		ctx.throw(500, e);
	}
};

function bufferToStream(binary) {
	const readableInstanceStream = new stream.Readable({
		read() {
			this.push(binary);
			this.push(null);
		},
	});

	return readableInstanceStream;
}

function detect(magic, buffer) {
	return new Promise((resolve, reject) => {
		magic.detect(buffer, (err, res) => {
			if (err) {
				reject(err);
			}
			resolve(res);
		});
	});
}

function gridStreamEventEmitter(stream, event) {
	return new Promise((resolve, reject) => {
		stream.on(event, data => {
			resolve(data);
		});
	});
}
