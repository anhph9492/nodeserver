import Router  from 'koa-router';

const attachment = new Router();
import {list, get,download, upload as uploadFunc, overwrite}  from './attachment.ctrl.js';

import multer  from '@koa/multer';
const upload = multer();

attachment.get('/', list);
attachment.get('/:_id', get);
attachment.get('/download/:_id', download);
attachment.post('/upload', upload.any(), uploadFunc);
attachment.post('/upload/:_id', upload.any(), overwrite);

export default attachment;