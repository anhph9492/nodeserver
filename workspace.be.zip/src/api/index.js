import Router from 'koa-router';
const api = new Router();

import commonApi from './api/index.js';
// import platz  from './platz/index.js';

api.use('/api', commonApi.routes());

// api.use('/platz', platz.routes());

export default api;
