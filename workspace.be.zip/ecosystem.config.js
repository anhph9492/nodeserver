export default {
  apps: [
    {
      name: 'backend',
      script: './src',
      watch: true,
      env_development: {
        NODE_PATH: "src",
      },
      env_production: {
        NODE_PATH: "src",
        NODE_ENV: "production"
      },
      instacnes: 4,
      exec_mode: 'cluster'
    }
  ]
}
