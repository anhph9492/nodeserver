npm start

