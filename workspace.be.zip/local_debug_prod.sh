NODE_ENV="production" MONGO_USER="platz" MONGO_PASS="dkagh1%40" MONGO_HOST="156.147.61.15:27017" MONGO_COLLECTION="platz" npm run debug

