## Clone the repo
### `git clone http://mod.lge.com/hub/platz/platz.be.git`

## To install
### `npm install`



## To run this app
### `npm start`
Now you can access on [http://localhost:4000]




## To set of environment
```
JWT_SECRET

LDAP_USER_ID( = release.tvsw)
LDAP_PASSWD
LDAP_URL( = ldaps://lgesaads01.lge.net)

MONGO_COLLECTION( = platz)
MONGO_HOST( = 10.157.92.247) for 
MONGO_USER( = "")
MONGO_PASS( = "")

NODE_ENV(= "")
PORT( = 4000)
```

when NODE_ENV set as "production", db host would be 
### `mongodb://MONGO_USER:MONGO_PASS@MONGO_HOST/MONGO_COLLECTION?replicaSet=rs0`

if not, default db uri would be set as 
### `mongodb://10.157.92.247/platz?replicaSet=rs0`

If node already exists, the existing version is used, and if it does not exist, **v18.10.0** is used.


## Release
when master branch is update, automatically below container would be built.
```
docker-registry.lge.com/project/platz/platz.be:dev
```

when tag is updage which is starting with "release_x.x.x" , automatically below container would be built.

but the version should be matched with value of version in packages.json
```
docker-registry.lge.com/project/platz/platz.be:x.x.x
docker-registry.lge.com/project/platz/platz.be:latest
```

## Page 
visit link to show [data modeling](http://mod.lge.com/hub/platz/platz.be/-/wikis/data-modeling)  structure   


## Deploy on production environment

### `kubectl rollout restart platz-be-dpl`

